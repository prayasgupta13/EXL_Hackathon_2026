"""
Tests for the DETERMINISTIC phases.
=====================================================================
Naming, drift detection, lineage and the std template must produce the
same result on every run — that is the auditability claim. These tests
pin that down and run in under a second with no credentials.

    pytest -q
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from accelerator.phases import (
    ProcedureParser,
    DriftDetector,
    LineageBuilder,
    blocking_procedures,
)
from accelerator.phases.registry_builder import RegistryRow
from accelerator.utils import load_procedures, naming


PROC_DIR = Path(__file__).parent.parent / "inputs" / "procedures"


# ---------------------------------------------------------------------
# Naming conventions
# ---------------------------------------------------------------------
def test_column_abbreviations_expand():
    assert naming.expand_column("cust_nm") == "customer_name"
    assert naming.expand_column("pol_start_dt") == "policy_start_date"
    assert naming.expand_column("claim_amt") == "claim_amount"
    # already-spelled names pass through untouched
    assert naming.expand_column("customer_name") == "customer_name"


def test_table_names_strip_layer_prefix():
    assert naming.std_table_name("dbo.stg_customer") == "customer"
    assert naming.std_table_name("stg_premium_txn") == "premium_transaction"
    # dwh keeps the dim_/fact_ warehouse convention
    assert naming.dwh_table_name("dbo.dim_customer", "stg_customer") == "dim_customer"


def test_type_mapping():
    assert naming.map_type("DECIMAL(18,2)") == "decimal(18,2)"
    assert naming.map_type("NVARCHAR(200)") == "string"
    assert naming.map_type("DATETIME") == "timestamp"
    assert naming.map_type("BIT") == "boolean"
    assert naming.map_type("SOMETHING_ODD") == "string"   # safe fallback


def test_audit_columns_recognised():
    # these are owned by the dwh layer and must never be treated as
    # source columns or reported as drift
    assert naming.is_audit_column("eff_start_dt")
    assert naming.is_audit_column("is_current")
    assert naming.is_audit_column("customer_sk")
    assert not naming.is_audit_column("cust_nm")


# ---------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------
def test_five_procedure_files_present():
    assert len(load_procedures(PROC_DIR)) == 5


def test_dynamic_sql_procedure_is_flagged():
    """Proc 05 must be refused, not silently mistranslated."""
    procs = load_procedures(PROC_DIR)
    purge = next(p for p in procs if "purge" in p.filename)
    ir = ProcedureParser(llm=None, dialect="tsql").parse(purge.sql)
    assert not ir.is_convertible
    assert any(u.reason.value == "dynamic_sql" for u in ir.unsupported)


# ---------------------------------------------------------------------
# Drift detection — the three seeded scenarios
# ---------------------------------------------------------------------
def _row(table, column, target_type, proc="dbo.usp_Test", layer="std"):
    return RegistryRow(
        registry_id="x", source_system="SQLSERVER_PROD01", source_dialect="tsql",
        procedure_name=proc, source_schema="dbo", source_table=table,
        source_column=column, source_type="", target_layer=layer,
        target_schema=layer, target_table=table, target_column=column,
        target_type=target_type,
    )


class _FakeDB:
    """Stands in for Databricks: returns a fixed raw-layer schema."""

    def __init__(self, schemas):
        self.schemas = schemas

    def table_schema(self, fq):
        if fq not in self.schemas:
            raise Exception("TABLE_OR_VIEW_NOT_FOUND")
        return self.schemas[fq]


def test_missing_column_is_a_blocker():
    db = _FakeDB({
        "hackathon.raw.stg_claims": [
            {"name": "claim_no", "type": "string"},
            {"name": "claim_amt", "type": "decimal(18,2)"},
        ]
    })
    rows = [
        _row("stg_claims", "claim_no", "string"),
        _row("stg_claims", "deductible_amt", "decimal(18,2)"),  # absent in raw
    ]
    findings = DriftDetector(db).detect(rows)

    missing = [f for f in findings if f.drift_type == "MISSING_COLUMN"]
    assert len(missing) == 1
    assert missing[0].column_name == "deductible_amt"
    assert missing[0].severity == "BLOCKER"
    # a blocker must stop code generation for that procedure
    assert "dbo.usp_Test" in blocking_procedures(findings)


def test_type_mismatch_is_a_warning_not_a_blocker():
    """String-vs-decimal is recoverable with a cast, so it warns."""
    db = _FakeDB({
        "hackathon.raw.stg_policy": [
            {"name": "pol_no", "type": "string"},
            {"name": "prem_amt", "type": "string"},   # raw landed a string
        ]
    })
    rows = [
        _row("stg_policy", "pol_no", "string"),
        _row("stg_policy", "prem_amt", "decimal(18,2)"),  # proc implies decimal
    ]
    findings = DriftDetector(db).detect(rows)

    mismatch = [f for f in findings if f.drift_type == "TYPE_MISMATCH"]
    assert len(mismatch) == 1
    assert mismatch[0].expected_value == "decimal(18,2)"
    assert mismatch[0].actual_value == "string"
    assert mismatch[0].severity == "WARNING"
    assert not blocking_procedures(findings)


def test_missing_table_is_a_blocker():
    db = _FakeDB({})  # raw layer has nothing
    rows = [_row("stg_premium_txn", "txn_amt", "decimal(18,2)")]
    findings = DriftDetector(db).detect(rows)

    assert len(findings) == 1
    assert findings[0].drift_type == "MISSING_TABLE"
    assert findings[0].severity == "BLOCKER"


def test_integer_widths_do_not_trigger_drift():
    """int vs bigint is not worth a human's attention."""
    db = _FakeDB({
        "hackathon.raw.stg_customer": [{"name": "cust_id", "type": "bigint"}]
    })
    findings = DriftDetector(db).detect([_row("stg_customer", "cust_id", "int")])
    assert not [f for f in findings if f.drift_type == "TYPE_MISMATCH"]


def test_extra_raw_column_is_reported_as_auto():
    """A column raw has but no procedure uses: informational, auto-adoptable."""
    db = _FakeDB({
        "hackathon.raw.stg_customer": [
            {"name": "cust_id", "type": "int"},
            {"name": "cust_email", "type": "string"},   # new at source
        ]
    })
    findings = DriftDetector(db).detect([_row("stg_customer", "cust_id", "int")])
    extra = [f for f in findings if f.drift_type == "EXTRA_COLUMN"]
    assert len(extra) == 1
    assert extra[0].column_name == "cust_email"
    assert extra[0].resolution_mode == "AUTO"
    assert not blocking_procedures(findings)


# ---------------------------------------------------------------------
# Lineage
# ---------------------------------------------------------------------
def test_lineage_traces_raw_to_std_to_dwh():
    rows = [
        _row("stg_customer", "cust_nm", "string", layer="std"),
        _row("stg_customer", "cust_nm", "string", layer="dwh"),
    ]
    rows[0].target_table = "customer"
    rows[0].target_column = "customer_name"
    rows[0].transform_rule = "INITCAP"
    rows[1].target_table = "dim_customer"
    rows[1].target_column = "customer_name"

    lineage = LineageBuilder().build(
        rows,
        business_keys={"dbo.usp_Test": ["cust_id"]},
        scd2_columns={"dbo.usp_Test": ["cust_nm"]},
    )

    assert len(lineage) == 1
    l = lineage[0]
    assert l.raw_table == "hackathon.raw.stg_customer"
    assert l.raw_column == "cust_nm"
    assert l.std_table == "hackathon.std.customer"
    assert l.std_column == "customer_name"
    assert l.std_transform == "INITCAP"
    assert l.dwh_table == "hackathon.dwh.dim_customer"
    assert l.dwh_column == "customer_name"
    assert l.is_scd2_tracked          # change here creates a new SCD2 version
    assert not l.is_business_key
