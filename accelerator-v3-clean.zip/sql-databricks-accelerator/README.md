# SQL → Databricks Migration Accelerator (v3)

Converts SQL Server stored procedures into a Databricks medallion
pipeline. The registry is **generated from the procedures**, drift is
**detected against the live raw layer**, and every column's journey is
recorded in a **lineage table** that the code generator resolves against.

## Pipeline

```
inputs/procedures/*.sql
        │
   PHASE 0  parse            ──► ProcedureIR  (flags dynamic SQL, cursors)
        │
   PHASE 1  registry build   ──► metadata.schema_registry   (appended)
        │
   PHASE 2  drift detect     ──► metadata.schema_drift      (appended)
        │     registry vs ACTUAL raw schema
        │     BLOCKER findings stop codegen for that procedure
        │
   PHASE 3  lineage build    ──► metadata.lineage           (appended)
        │     raw.col → std.col → dwh.col, with transforms
        │
   PHASE 4  codegen          ──► outputs/generated/<proc>/
              raw→std : deterministic template (no LLM)
              std→dwh : LLM, grounded on lineage
        │
        └──► metadata.execution_log  (every phase, every run)
```

## Layout

```
├── inputs/procedures/          one .sql file per stored procedure
├── sql/
│   ├── source/                 SQL Server reference DDL
│   └── databricks/
│       ├── 01_create_medallion.sql        raw / std / dwh + seed data
│       └── 02_create_metadata_tables.sql  registry, drift, lineage, log
├── outputs/                    generated code + CSV mirrors of metadata
├── src/accelerator/
│   ├── connections/            Databricks + LLM clients (isolated)
│   ├── ir/                     intermediate representation
│   ├── phases/                 the five pipeline phases
│   └── utils/                  naming conventions, procedure loader
├── tests/
└── run_accelerator.py
```

## Setup

```bash
python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # fill in Databricks + Anthropic details
```

Then in a Databricks SQL editor, run in order:
1. `sql/databricks/01_create_medallion.sql`
2. `sql/databricks/02_create_metadata_tables.sql`

## Run

```bash
python run_accelerator.py                    # all phases
python run_accelerator.py --until drift      # stop and review drift first
python run_accelerator.py --offline          # no warehouse (drift skipped)
python run_accelerator.py --ignore-drift     # generate despite blockers
```

## The five sample procedures

| File | Pattern | Expected outcome |
|---|---|---|
| `01_usp_load_dim_customer` | SCD2 | Converts cleanly |
| `02_usp_load_fact_claims` | Fact, temp table, joins | **BLOCKED** — `deductible_amt` missing from raw |
| `03_usp_load_dim_policy` | SCD2 | Converts, with a **type-mismatch warning** (`prem_amt` is STRING in raw) |
| `04_usp_load_fact_premium` | Aggregate | **BLOCKED** — `stg_premium_txn` not landed in raw |
| `05_usp_purge_old_partitions` | Dynamic SQL | **Human review** — review packet written |

The raw layer in `01_create_medallion.sql` is deliberately incomplete.
Those gaps are what the drift detector finds — don't "fix" them before
running the accelerator.

## Why the LLM is confined to one layer

`raw → std` is mechanical (rename, cast, cleanse), so it is produced by
a Python template from the lineage table: same input, byte-identical
output, every time. `std → dwh` carries the business logic (SCD2 merges,
joins, aggregations), which genuinely needs a model — and even there the
prompt supplies exact column names from lineage rather than letting the
model choose them.

## Test

```bash
pytest -q
```

Covers naming derivation, all four drift types, blocker-vs-warning
severity, and lineage assembly — the parts that must be reproducible.
