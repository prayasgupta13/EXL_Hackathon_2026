#!/usr/bin/env python3
"""
Accelerator entry point — phased pipeline.
=====================================================================
    PHASE 0  parse       .sql files          -> ProcedureIR
    PHASE 1  registry    IR                  -> metadata.schema_registry
    PHASE 2  drift       registry vs raw     -> metadata.schema_drift
    PHASE 3  lineage     registry            -> metadata.lineage
    PHASE 4  codegen     lineage + IR        -> outputs/generated/*.py

Examples
--------
    # Everything, against Databricks
    python run_accelerator.py

    # Stop after drift detection (review before generating any code)
    python run_accelerator.py --until drift

    # No warehouse: parse + registry + lineage + codegen, drift skipped
    python run_accelerator.py --offline

    # Generate even where BLOCKER drift was found (not recommended)
    python run_accelerator.py --ignore-drift
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from accelerator.connections import DatabricksClient, LLMClient   # noqa: E402
from accelerator.phases import (                                   # noqa: E402
    ProcedureParser,
    RegistryBuilder,
    DriftDetector,
    LineageBuilder,
    CodeGenerator,
    MetadataWriter,
    WorkspaceUploader,
    blocking_procedures,
    lineage_for_procedure,
    new_run_id,
)
from accelerator.utils import load_procedures                      # noqa: E402

PHASES = ["parse", "registry", "drift", "lineage", "codegen"]


def _now() -> datetime:
    return datetime.now(timezone.utc)


def main() -> int:
    ap = argparse.ArgumentParser(description="SQL -> Databricks accelerator")
    ap.add_argument("--procedures", default="inputs/procedures",
                    help="Folder holding one .sql file per procedure")
    ap.add_argument("--outputs", default="outputs",
                    help="Where artifacts and generated code are written")
    ap.add_argument("--catalog", default="hackathon")
    ap.add_argument("--until", choices=PHASES, default="codegen",
                    help="Stop after this phase")
    ap.add_argument("--offline", action="store_true",
                    help="Skip Databricks; drift detection is unavailable")
    ap.add_argument("--ignore-drift", action="store_true",
                    help="Generate code even for procedures with BLOCKER drift")
    ap.add_argument("--upload", action="store_true",
                    help="Upload generated notebooks into the Databricks "
                         "workspace under /Workspace/Users/accelerator_output")
    args = ap.parse_args()

    stop_after = PHASES.index(args.until)
    out_dir = Path(args.outputs)
    run_id = new_run_id()

    print(f"Run id: {run_id}")
    print(f"Mode:   {'OFFLINE' if args.offline else 'DATABRICKS'}")
    print(f"Stops after phase: {args.until}\n")

    llm = LLMClient.from_env(
        audit_log_path=out_dir / "_audit" / "agent_calls.jsonl"
    )

    db = None
    if not args.offline:
        db = DatabricksClient.from_env()
        db.__enter__()

    writer = MetadataWriter(out_dir, db=db, catalog=args.catalog)
    if db is not None:
        writer.ensure_tables()

    try:
        # =============================================================
        # PHASE 0 — parse
        # =============================================================
        print("=" * 68)
        print("PHASE 0 — Parsing stored procedures")
        print("=" * 68)

        proc_files = load_procedures(args.procedures)
        parser = ProcedureParser(llm, dialect="tsql")

        parsed: list[tuple[str, object]] = []   # (filename, ir)
        unsupported: list[tuple[str, object]] = []

        for pf in proc_files:
            t0 = _now()
            ir = parser.parse(pf.sql)
            if ir.is_convertible:
                parsed.append((pf.filename, ir))
                status, msg = "SUCCESS", "parsed"
                print(f"  [ok]     {pf.filename}  ->  {ir.procedure_name}")
            else:
                unsupported.append((pf.filename, ir))
                reasons = "; ".join(u.reason.value for u in ir.unsupported)
                status, msg = "HUMAN_REVIEW", reasons
                print(f"  [review] {pf.filename}  ->  {reasons}")
            writer.log_run(run_id, "PARSE", ir.procedure_name, status,
                           message=msg, started_at=t0)

        if stop_after == 0:
            return _finish(db, run_id, out_dir)

        # =============================================================
        # PHASE 1 — registry
        # =============================================================
        print("\n" + "=" * 68)
        print("PHASE 1 — Generating schema registry from procedures")
        print("=" * 68)

        builder = RegistryBuilder(llm, catalog=args.catalog)
        registry_rows = []
        ir_by_proc = {}

        for filename, ir in parsed:
            t0 = _now()
            rows = builder.build(_sql_of(proc_files, filename), ir)
            registry_rows.extend(rows)
            ir_by_proc[ir.procedure_name] = ir
            print(f"  {ir.procedure_name}: {len(rows)} mapping rows")
            writer.log_run(run_id, "REGISTRY", ir.procedure_name, "SUCCESS",
                           rows_affected=len(rows), started_at=t0)

        payload = [r.to_dict() for r in registry_rows]
        writer.write_csv("schema_registry.csv", payload)
        n = writer.write_table("schema_registry", payload)
        print(f"\n  Total: {len(registry_rows)} rows "
              f"({n} appended to Databricks)" if n else
              f"\n  Total: {len(registry_rows)} rows (offline: CSV only)")

        if stop_after == 1:
            return _finish(db, run_id, out_dir)

        # =============================================================
        # PHASE 2 — drift
        # =============================================================
        print("\n" + "=" * 68)
        print("PHASE 2 — Detecting schema drift (registry vs raw layer)")
        print("=" * 68)

        findings = []
        blocked: set[str] = set()

        if db is None:
            print("  SKIPPED — drift detection needs a live raw layer.")
            writer.log_run(run_id, "DRIFT", "*", "SKIPPED",
                           message="offline mode")
        else:
            t0 = _now()
            detector = DriftDetector(db, catalog=args.catalog)
            findings = detector.detect(registry_rows)
            blocked = blocking_procedures(findings)

            for f in findings:
                marker = "BLOCK" if f.severity == "BLOCKER" else "warn "
                target = f.column_name or f.source_table
                print(f"  [{marker}] {f.drift_type:<15} {target}")
                print(f"           expected: {f.expected_value}")
                print(f"           actual:   {f.actual_value}")

            if not findings:
                print("  No drift detected.")

            payload = [f.to_dict() for f in findings]
            writer.write_csv("schema_drift.csv", payload)
            writer.write_table("schema_drift", payload)
            writer.log_run(run_id, "DRIFT", "*", "SUCCESS",
                           rows_affected=len(findings), started_at=t0)

            if blocked:
                print(f"\n  {len(blocked)} procedure(s) blocked by drift: "
                      f"{', '.join(sorted(blocked))}")

        if stop_after == 2:
            return _finish(db, run_id, out_dir)

        # =============================================================
        # PHASE 3 — lineage
        # =============================================================
        print("\n" + "=" * 68)
        print("PHASE 3 — Building column lineage (raw -> std -> dwh)")
        print("=" * 68)

        t0 = _now()
        lineage_builder = LineageBuilder(catalog=args.catalog)
        lineage_rows = lineage_builder.build(
            registry_rows,
            business_keys={p: ir.business_key for p, ir in ir_by_proc.items()},
            scd2_columns={
                p: ir.scd_compare_columns for p, ir in ir_by_proc.items()
            },
        )
        print(f"  {len(lineage_rows)} column paths traced")

        payload = [l.to_dict() for l in lineage_rows]
        writer.write_csv("lineage.csv", payload)
        writer.write_table("lineage", payload)
        writer.log_run(run_id, "LINEAGE", "*", "SUCCESS",
                       rows_affected=len(lineage_rows), started_at=t0)

        if stop_after == 3:
            return _finish(db, run_id, out_dir)

        # =============================================================
        # PHASE 4 — codegen
        # =============================================================
        print("\n" + "=" * 68)
        print("PHASE 4 — Generating Databricks code from lineage")
        print("=" * 68)

        gen_dir = out_dir / "generated"
        generator = CodeGenerator(llm, catalog=args.catalog)
        converted = 0

        for filename, ir in parsed:
            proc = ir.procedure_name
            t0 = _now()

            # Match on the bare procedure name (drop any schema prefix):
            # drift findings store 'usp_X' while the IR uses 'dbo.usp_X'.
            # Without this, blocked procedures slip through to codegen and
            # produce broken notebooks against non-existent tables.
            blocked_bare = {b.split(".")[-1].lower() for b in blocked}
            if proc.split(".")[-1].lower() in blocked_bare and not args.ignore_drift:
                print(f"  [skip]   {proc} — blocked by BLOCKER drift")
                writer.log_run(run_id, "CODEGEN", proc, "SKIPPED",
                               message="blocking schema drift", started_at=t0)
                continue

            proc_lineage = lineage_for_procedure(lineage_rows, proc)
            if not proc_lineage:
                print(f"  [skip]   {proc} — no lineage rows")
                writer.log_run(run_id, "CODEGEN", proc, "SKIPPED",
                               message="no lineage", started_at=t0)
                continue

            code = generator.generate(ir, proc_lineage)
            proc_dir = gen_dir / proc.replace(".", "_")
            proc_dir.mkdir(parents=True, exist_ok=True)

            written = []
            if code.std_notebook:
                p = proc_dir / "std_notebook.py"
                p.write_text(code.std_notebook, encoding="utf-8")
                written.append(p.name)
            if code.dwh_notebook:
                p = proc_dir / "dwh_notebook.py"
                p.write_text(code.dwh_notebook, encoding="utf-8")
                written.append(p.name)

            converted += 1
            print(f"  [ok]     {proc} -> {proc_dir}/  ({', '.join(written)})")
            writer.log_run(run_id, "CODEGEN", proc, "SUCCESS",
                           rows_affected=len(written), started_at=t0)

        # -- review packets for unsupported procedures ----------------
        if unsupported:
            review_dir = out_dir / "_review"
            review_dir.mkdir(parents=True, exist_ok=True)
            for filename, ir in unsupported:
                path = review_dir / f"{ir.procedure_name}.md"
                path.write_text(_review_packet(ir, filename), encoding="utf-8")
                print(f"  [review] {ir.procedure_name} -> {path}")

        # =============================================================
        # PHASE 5 — upload generated notebooks to the workspace (opt-in)
        # =============================================================
        uploaded_count = 0
        if args.upload:
            print("\n" + "=" * 68)
            print("PHASE 5 — Uploading notebooks to the Databricks workspace")
            print("=" * 68)
            if args.offline:
                print("  SKIPPED — --upload needs a workspace connection "
                      "(don't combine with --offline).")
            else:
                t0 = _now()
                uploader = WorkspaceUploader()
                try:
                    results = uploader.upload_generated(gen_dir)
                    for r in results:
                        if r.ok:
                            uploaded_count += 1
                            print(f"  [ok]     {r.workspace_path}")
                        else:
                            print(f"  [fail]   {r.local_path}: {r.message}")
                    writer.log_run(run_id, "UPLOAD", "*", "SUCCESS",
                                   rows_affected=uploaded_count, started_at=t0)
                except Exception as exc:
                    print(f"  ERROR uploading to workspace: {exc}")
                    writer.log_run(run_id, "UPLOAD", "*", "FAILED",
                                   message=str(exc), started_at=t0)

        # -- summary ---------------------------------------------------
        total = len(proc_files)
        print(f"SUMMARY  ({total} procedures)")
        print("=" * 68)
        print(f"  converted            : {converted}")
        blocked_bare = {b.split(".")[-1].lower() for b in blocked}
        print(f"  blocked by drift     : "
              f"{len([1 for f, i in parsed if i.procedure_name.split('.')[-1].lower() in blocked_bare])}")
        print(f"  human review needed  : {len(unsupported)}")
        print(f"  drift findings       : {len(findings)}")
        print(f"\n  Artifacts: {out_dir}/")
        print(f"  Generated code: {gen_dir}/")
        if args.upload and uploaded_count:
            print(f"  Uploaded to workspace: "
                  f"/Workspace/Users/accelerator_output/ ({uploaded_count} notebooks)")

        return _finish(db, run_id, out_dir)

    finally:
        if db is not None:
            db.__exit__(None, None, None)


def _sql_of(proc_files, filename: str) -> str:
    """Fetch the raw SQL for a filename from the loaded procedure list."""
    return next(p.sql for p in proc_files if p.filename == filename)


def _review_packet(ir, filename: str) -> str:
    """Markdown handoff for a procedure the accelerator refused to convert."""
    lines = [
        f"# Human review required: `{ir.procedure_name}`\n",
        f"**Source file:** `{filename}`  ",
        f"**Generated:** {datetime.now():%Y-%m-%d %H:%M}\n",
        "## Why it was not converted\n",
    ]
    for u in ir.unsupported:
        lines.append(f"- **{u.reason.value}** — {u.note}")
        if u.snippet:
            lines.append(f"  - Snippet: `{u.snippet}`")

    lines += [
        "\n## What the parser did establish\n",
        f"- Dialect: {ir.dialect}",
        f"- Tables referenced: "
        f"{', '.join(ir.source_tables) if ir.source_tables else 'none'}",
        "\n## Suggested approach\n",
        "- Replace runtime-built SQL with an explicit job parameter "
        "(widget); Databricks parameterises natively.",
        "- Add an allow-list check against `metadata.schema_registry` so "
        "only managed tables can be targeted.",
        "- Consider whether Delta retention + `VACUUM` fits better than a "
        "scheduled `DELETE`.",
        "- Run the finished notebook through the same validation checks as "
        "generated code.",
        "\n## Reviewer decision\n",
        "| Field | Value |",
        "|---|---|",
        "| Reviewer | _<name>_ |",
        "| Date | _<yyyy-mm-dd>_ |",
        "| Decision | _convert manually / redesign / retire / defer_ |",
        "| Manual artifact | _<path>_ |",
    ]
    return "\n".join(lines)


def _finish(db, run_id: str, out_dir: Path) -> int:
    print(f"\nRun {run_id} complete. Execution log: {out_dir}/execution_log.csv")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
