"""
LLM connection layer (Anthropic / Claude).
=====================================================================
Isolates every call to Claude behind one small interface so the agents
depend on `LLMClient.complete(...)`, not on the Anthropic SDK directly.
Benefits:
  - swap models or providers in one place
  - centralise logging of prompt/response pairs (enterprise audit req.)
  - make agents trivially mockable in unit tests

The Parser/IR Agent and the Codegen Agent use this. The Mapping & Drift
and Validation agents are deterministic Python and do NOT need the LLM.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# `anthropic` is imported lazily inside from_env() so that importing the
# agents (for the deterministic path / tests) doesn't require the SDK.

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    def load_dotenv(*_args, **_kwargs):
        return False


@dataclass
class LLMClient:
    """Wrapper around the Anthropic client with optional audit logging."""

    model: str
    _client: Any = field(repr=False)  # anthropic.Anthropic at runtime
    audit_log_path: Path | None = None  # if set, every call is logged as JSONL

    @classmethod
    def from_env(cls, audit_log_path: str | Path | None = None) -> "LLMClient":
        """Read ANTHROPIC_* vars from .env and build a client."""
        import anthropic  # deferred import

        load_dotenv()

        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise EnvironmentError(
                "ANTHROPIC_API_KEY not set. Copy .env.example to .env "
                "and add your key."
            )

        # base_url is optional — only set if the user proxies through a
        # local endpoint (e.g. Claude Code). Passing None uses the default.
        base_url = os.getenv("ANTHROPIC_BASE_URL") or None
        client = anthropic.Anthropic(api_key=api_key, base_url=base_url)

        return cls(
            model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
            _client=client,
            audit_log_path=Path(audit_log_path) if audit_log_path else None,
        )

    def complete(
        self,
        system: str,
        user: str,
        *,
        max_tokens: int = 4096,
        temperature: float = 0.0,  # deterministic by default: repeatability matters
    ) -> str:
        """
        Send a single-turn message and return Claude's text response.

        temperature defaults to 0 because code generation and parsing
        should be as repeatable as possible (a Stage-1 recommendation:
        "improve repeatability and auditability").
        """
        response = self._client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system,
            messages=[{"role": "user", "content": user}],
        )

        # Anthropic responses are a list of content blocks; concatenate
        # any text blocks into a single string.
        text = "".join(
            block.text for block in response.content if block.type == "text"
        )

        self._audit(system, user, text)
        return text

    def complete_json(self, system: str, user: str, **kwargs) -> dict:
        """
        Same as complete(), but parse the response as JSON.
        Strips ```json fences if the model wrapped its output in them.
        Used by the Parser/IR agent, which must return structured data.
        """
        raw = self.complete(system, user, **kwargs)
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            # remove opening ```json / ``` and closing ```
            cleaned = cleaned.split("```", 2)[1]
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
            cleaned = cleaned.rsplit("```", 1)[0]
        return json.loads(cleaned)

    # -- audit --------------------------------------------------------
    def _audit(self, system: str, user: str, response: str) -> None:
        """
        Append the prompt/response to a JSONL file if audit logging is on.
        This directly supports the 'prompt/response logging' enterprise
        requirement from the Stage-1 feedback. In production these rows
        would land in a Delta table (config.agent_audit_log) instead.
        """
        if not self.audit_log_path:
            return
        self.audit_log_path.parent.mkdir(parents=True, exist_ok=True)
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "model": self.model,
            "system": system,
            "user": user,
            "response": response,
        }
        with self.audit_log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
