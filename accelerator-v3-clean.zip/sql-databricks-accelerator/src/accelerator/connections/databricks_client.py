"""
Databricks connection layer.
=====================================================================
ALL Databricks connectivity lives in this one module so the rest of
the accelerator never touches connection details directly. If the
auth mechanism changes (PAT -> OAuth, SQL warehouse -> serverless),
this is the only file that changes.

Two responsibilities:
  1. Open a connection to a SQL Warehouse using credentials from .env
  2. Provide thin, well-typed helpers the agents use:
       - run_query()      -> returns rows as list[dict]
       - execute()        -> runs DDL/DML, returns affected-row info
       - load_registry()  -> pulls the active column mappings
       - table_schema()   -> DESCRIBE a table (used by contract tests)

Usage:
    from accelerator.connections import DatabricksClient
    with DatabricksClient.from_env() as db:
        rows = db.run_query("SELECT * FROM hackathon.config.schema_registry")
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

# NOTE: the databricks-sql-connector import is deferred into __enter__()
# (see below) so that importing this module — and therefore the agents —
# does NOT require the driver to be installed. This keeps the
# deterministic parts of the pipeline (parser, mapping) usable and
# testable in an environment without the Databricks packages.

# python-dotenv is lightweight and always needed to read .env, so it is
# imported eagerly but guarded for environments without it.
try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - dotenv is in requirements.txt
    def load_dotenv(*_args, **_kwargs):
        """No-op fallback if python-dotenv isn't installed."""
        return False


@dataclass
class DatabricksConfig:
    """Connection settings, populated from environment variables."""

    host: str
    http_path: str
    token: str
    catalog: str
    config_schema: str

    @classmethod
    def from_env(cls) -> "DatabricksConfig":
        """
        Build config from the .env file / process environment.
        Raises a clear error early if a required variable is missing,
        so we fail at startup rather than mid-pipeline.
        """
        load_dotenv()  # no-op if there is no .env; reads it if present

        required = {
            "DATABRICKS_HOST": os.getenv("DATABRICKS_HOST"),
            "DATABRICKS_HTTP_PATH": os.getenv("DATABRICKS_HTTP_PATH"),
            "DATABRICKS_TOKEN": os.getenv("DATABRICKS_TOKEN"),
        }
        missing = [k for k, v in required.items() if not v]
        if missing:
            raise EnvironmentError(
                "Missing Databricks env vars: "
                + ", ".join(missing)
                + ". Copy .env.example to .env and fill them in."
            )

        # Strip a leading https:// if the user pasted the full URL —
        # the connector wants a bare hostname.
        host = required["DATABRICKS_HOST"].replace("https://", "").rstrip("/")

        return cls(
            host=host,
            http_path=required["DATABRICKS_HTTP_PATH"],
            token=required["DATABRICKS_TOKEN"],
            catalog=os.getenv("DATABRICKS_CATALOG", "hackathon"),
            config_schema=os.getenv("DATABRICKS_CONFIG_SCHEMA", "config"),
        )


class DatabricksClient:
    """
    Thin wrapper around a databricks-sql connection.

    Designed as a context manager so the connection is always closed:
        with DatabricksClient.from_env() as db:
            ...
    """

    def __init__(self, config: DatabricksConfig):
        self.config = config
        self._connection = None  # opened lazily in __enter__

    # -- lifecycle ----------------------------------------------------
    @classmethod
    def from_env(cls) -> "DatabricksClient":
        """Convenience constructor: read .env and return a client."""
        return cls(DatabricksConfig.from_env())

    def __enter__(self) -> "DatabricksClient":
        """Open the connection when entering a `with` block."""
        # Deferred import: only needed when we actually connect, so the
        # driver isn't required just to import the agents.
        from databricks import sql as databricks_sql

        self._connection = databricks_sql.connect(
            server_hostname=self.config.host,
            http_path=self.config.http_path,
            access_token=self.config.token,
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Always close the connection, even if an error occurred."""
        if self._connection is not None:
            self._connection.close()
            self._connection = None

    # -- core query helpers ------------------------------------------
    def run_query(self, query: str, params: dict | None = None) -> list[dict[str, Any]]:
        """
        Run a SELECT and return rows as a list of dicts (column -> value).
        Using dicts (not tuples) keeps agent code readable: row["target_column"].
        """
        if self._connection is None:
            raise RuntimeError("Connection not open. Use inside a `with` block.")

        with self._connection.cursor() as cursor:
            cursor.execute(query, params or {})
            columns = [c[0] for c in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]

    def execute(self, statement: str) -> None:
        """
        Run DDL/DML (CREATE, INSERT, MERGE) where no rows come back.
        Kept separate from run_query() to make intent explicit at call sites.
        """
        if self._connection is None:
            raise RuntimeError("Connection not open. Use inside a `with` block.")

        with self._connection.cursor() as cursor:
            cursor.execute(statement)

    # -- domain helpers the agents use -------------------------------
    def load_registry(self, source_table: str | None = None) -> list[dict[str, Any]]:
        """
        Pull the ACTIVE column mappings from the config registry.
        Only is_active = true rows are returned, so expired/superseded
        drift versions are automatically excluded — the Mapping & Drift
        Agent always sees the current truth.

        If source_table is given (e.g. 'dbo.stg_customer') the result is
        filtered to that table's mappings.
        """
        fq_registry = (
            f"{self.config.catalog}.{self.config.config_schema}.schema_registry"
        )
        query = f"""
            SELECT source_system, source_schema, source_table, source_column,
                   source_type, target_layer, target_schema, target_table,
                   target_column, target_type, transform_rule, default_value,
                   confidence_score, approved_by
            FROM {fq_registry}
            WHERE is_active = true
        """
        rows = self.run_query(query)

        if source_table:
            # source_table arrives as 'dbo.stg_customer'; split into parts
            schema, _, table = source_table.partition(".")
            rows = [
                r
                for r in rows
                if r["source_schema"] == schema and r["source_table"] == table
            ]
        return rows

    def table_schema(self, fq_table: str) -> list[dict[str, str]]:
        """
        Return [{name, type}, ...] for a table, via DESCRIBE.
        The Validation Agent compares this against the registry to run
        the per-layer schema contract test.
        """
        rows = self.run_query(f"DESCRIBE TABLE {fq_table}")
        # DESCRIBE returns col_name / data_type / comment; the trailing
        # partition-info rows have blank/# col_name — filter them out.
        return [
            {"name": r["col_name"], "type": r["data_type"]}
            for r in rows
            if r.get("col_name") and not r["col_name"].startswith("#")
        ]
