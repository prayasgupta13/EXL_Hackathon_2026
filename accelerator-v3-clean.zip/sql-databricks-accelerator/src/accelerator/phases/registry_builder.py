"""
PHASE 1 — Registry Builder
=====================================================================
Reads every stored procedure in the input folder and GENERATES the
schema registry: one row per source column per target layer.

This inverts the old design. The registry used to be hand-authored and
the accelerator read it; now the procedures are the source of truth and
the registry is derived from them. Adding a procedure to the input
folder extends the registry — nothing is hand-maintained.

Determinism: column/table name derivation is rule-based (utils.naming).
The LLM is used only to extract structure from the procedure (which
columns belong to which table, what is derived, what the types are),
never to invent target names.

Output: list[RegistryRow], appended to hackathon.metadata.schema_registry
        and mirrored to outputs/schema_registry.csv for offline review.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone

from accelerator.connections import LLMClient
from accelerator.ir import ProcedureIR
from accelerator.utils import naming


@dataclass
class RegistryRow:
    """One source-column -> target-column mapping, for one layer."""

    registry_id: str
    source_system: str
    source_dialect: str
    procedure_name: str
    source_schema: str
    source_table: str
    source_column: str
    source_type: str
    target_layer: str
    target_schema: str
    target_table: str
    target_column: str
    target_type: str
    transform_rule: str = ""
    is_derived: bool = False
    derivation_logic: str = ""
    generated_on: str = ""
    generated_by: str = "registry_builder"

    def to_dict(self) -> dict:
        return asdict(self)


# The LLM's only job here: pull structure out of the procedure. It is
# explicitly told NOT to rename anything — naming is our deterministic
# concern, not its.
_EXTRACT_PROMPT = """\
You analyse a single SQL Server stored procedure and return ONLY JSON.

Return this exact shape:
{
  "procedure_name": string,
  "source_tables": [
     {"schema": string, "table": string,
      "columns": [{"name": string, "sql_type": string|null}]}
  ],
  "target_table": string|null,
  "load_pattern": "scd2"|"fact_append"|"aggregate"|"full_refresh"|"unknown",
  "business_key": [string],
  "scd_compare_columns": [string],
  "derived_columns": [
     {"name": string, "expression": string, "description": string}
  ],
  "joins": [{"left_table","right_table","join_type","on_condition"}],
  "filters": [string]
}

Rules:
- List columns using their ORIGINAL names exactly as they appear. Do NOT
  rename, expand, or standardise them — that is handled elsewhere.
- sql_type: infer from usage where the procedure does not declare it
  (e.g. a column compared to a string literal is NVARCHAR; one summed is
  DECIMAL(18,2)). Use null only when you genuinely cannot tell.
- Only list STAGING/source tables under source_tables (tables the proc
  READS). The table it writes to goes in target_table.
- derived_columns are values COMPUTED in the procedure (CASE, DATEDIFF,
  SUM, arithmetic), not columns selected straight from a source.
- Output raw JSON only. No markdown fences, no prose.
"""


class RegistryBuilder:
    """Generates registry rows from stored procedures."""

    def __init__(
        self,
        llm: LLMClient,
        catalog: str = "hackathon",
        source_system: str = "SQLSERVER_PROD01",
        dialect: str = "tsql",
    ):
        self.llm = llm
        self.catalog = catalog
        self.source_system = source_system
        self.dialect = dialect

    # -----------------------------------------------------------------
    def build(self, procedure_sql: str, ir: ProcedureIR) -> list[RegistryRow]:
        """
        Produce registry rows for one procedure.

        `ir` carries the deterministic parse (unsupported constructs,
        table list). If the procedure is not convertible we return no
        rows — an unparseable procedure must not pollute the registry.
        """
        if not ir.is_convertible:
            return []

        extracted = self.llm.complete_json(_EXTRACT_PROMPT, procedure_sql)
        return self._rows_from_extract(extracted, ir)

    # -----------------------------------------------------------------
    def _rows_from_extract(self, data: dict, ir: ProcedureIR) -> list[RegistryRow]:
        """Turn the LLM's structural extract into registry rows."""
        rows: list[RegistryRow] = []
        now = datetime.now(timezone.utc).isoformat()

        proc_name = data.get("procedure_name") or ir.procedure_name
        target_table = data.get("target_table")

        for tbl in data.get("source_tables", []):
            src_schema = (tbl.get("schema") or "dbo").lower()
            src_table = (tbl.get("table") or "").lower()
            if not src_table:
                continue

            # Skip the procedure's own target if the model listed it as a
            # source — dimensions are read for SCD2 comparison, but they
            # are not a raw-layer source table.
            if target_table and src_table == target_table.split(".")[-1].lower():
                continue

            # Skip OTHER warehouse tables the procedure only joins to for a
            # lookup (e.g. a fact proc joining dim_customer to resolve a
            # surrogate key). These dim_/fact_ tables live in dwh, not raw,
            # so they must not be checked against the raw layer — doing so
            # produces a false MISSING_TABLE drift.
            leaf = src_table.split("_", 1)[0]
            if leaf in {"dim", "fact"}:
                continue

            std_tbl = naming.std_table_name(src_table)
            dwh_tbl = naming.dwh_table_name(target_table, src_table)

            for col in tbl.get("columns", []):
                col_name = (col.get("name") or "").strip()
                if not col_name or naming.is_audit_column(col_name):
                    continue

                sql_type = col.get("sql_type")
                spark_type = naming.map_type(sql_type)
                # Enforce type by column-name convention (id/sk/flag/count)
                # so a JOIN-only id column isn't mislabelled string by the LLM.
                spark_type = naming.refine_type_by_name(col_name, spark_type)
                target_col = naming.expand_column(col_name)

                # std layer row
                rows.append(
                    self._row(
                        proc_name, src_schema, src_table, col_name,
                        sql_type or "", "std", "std", std_tbl,
                        target_col, spark_type,
                        transform=self._infer_transform(col_name, spark_type),
                        now=now,
                    )
                )
                # dwh layer row
                rows.append(
                    self._row(
                        proc_name, src_schema, src_table, col_name,
                        sql_type or "", "dwh", "dwh", dwh_tbl,
                        target_col, spark_type, transform="", now=now,
                    )
                )

        # Derived columns exist only in dwh — they are computed by the
        # procedure's business logic, not present in any source table.
        primary_src = None
        for tbl in data.get("source_tables", []):
            t = (tbl.get("table") or "").lower()
            if t and (not target_table or t != target_table.split(".")[-1].lower()):
                primary_src = (tbl.get("schema") or "dbo").lower(), t
                break

        for d in data.get("derived_columns", []):
            name = (d.get("name") or "").strip()
            if not name:
                continue
            src_schema, src_table = primary_src or ("dbo", "")
            rows.append(
                self._row(
                    proc_name, src_schema, src_table, name, "",
                    "dwh", "dwh",
                    naming.dwh_table_name(target_table, src_table),
                    naming.expand_column(name), "string",
                    transform="", now=now,
                    is_derived=True,
                    derivation=d.get("expression", ""),
                )
            )

        return rows

    # -----------------------------------------------------------------
    def _row(
        self, proc, src_schema, src_table, src_col, src_type,
        layer, tgt_schema, tgt_table, tgt_col, tgt_type,
        transform, now, is_derived=False, derivation="",
    ) -> RegistryRow:
        """Build one row, with a deterministic id so reruns dedupe."""
        key = f"{self.source_system}|{src_schema}.{src_table}.{src_col}|{layer}"
        registry_id = hashlib.sha256(key.encode()).hexdigest()[:16]

        return RegistryRow(
            registry_id=registry_id,
            source_system=self.source_system,
            source_dialect=self.dialect,
            procedure_name=proc,
            source_schema=src_schema,
            source_table=src_table,
            source_column=src_col,
            source_type=src_type,
            target_layer=layer,
            target_schema=tgt_schema,
            target_table=tgt_table,
            target_column=tgt_col,
            target_type=tgt_type,
            transform_rule=transform,
            is_derived=is_derived,
            derivation_logic=derivation,
            generated_on=now,
        )

    @staticmethod
    def _infer_transform(col_name: str, spark_type: str) -> str:
        """
        Standard std-layer cleansing, chosen by column semantics.
        Deterministic so the same column always gets the same treatment.
        """
        n = col_name.lower()
        if spark_type != "string":
            return ""
        if "email" in n:
            return "LOWER"
        if any(k in n for k in ("sts", "status", "seg", "typ", "type", "flag")):
            return "UPPER"
        if any(k in n for k in ("city", "nm", "name")):
            return "INITCAP"
        return "TRIM"
