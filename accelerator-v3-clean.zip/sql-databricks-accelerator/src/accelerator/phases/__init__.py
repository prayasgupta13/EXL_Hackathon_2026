"""
Pipeline phases, in execution order:

  0. ProcedureParser   .sql file          -> ProcedureIR (+ unsupported flags)
  1. RegistryBuilder   ProcedureIR        -> schema_registry rows
  2. DriftDetector     registry vs raw    -> schema_drift rows
  3. LineageBuilder    registry           -> lineage rows (raw->std->dwh)
  4. CodeGenerator     lineage + IR       -> std (template) + dwh (LLM) code
     MetadataWriter    all of the above   -> Delta tables + CSV mirrors
"""
from .procedure_parser import ProcedureParser
from .registry_builder import RegistryBuilder, RegistryRow
from .drift_detector import DriftDetector, DriftFinding, blocking_procedures
from .lineage_builder import LineageBuilder, LineageRow, lineage_for_procedure
from .codegen import CodeGenerator, GeneratedCode
from .metadata_writer import MetadataWriter, new_run_id
from .workspace_uploader import WorkspaceUploader, UploadResult

__all__ = [
    "ProcedureParser", "RegistryBuilder", "RegistryRow",
    "DriftDetector", "DriftFinding", "blocking_procedures",
    "LineageBuilder", "LineageRow", "lineage_for_procedure",
    "CodeGenerator", "GeneratedCode",
    "MetadataWriter", "new_run_id",
    "WorkspaceUploader", "UploadResult",
]
