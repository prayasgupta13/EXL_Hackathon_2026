"""
PHASE 3 — Lineage Builder
=====================================================================
Collapses the registry (one row per column PER LAYER) into a single row
per column describing its whole journey:

    raw.stg_customer.cust_nm
        -> std.customer.customer_name      (TRIM/INITCAP)
        -> dwh.dim_customer.customer_name  (SCD2-tracked)

Why this matters: the code generator resolves names through the lineage
table rather than re-deriving them. That guarantees generated code and
the recorded lineage can never disagree — the lineage IS the contract.

It is also the artifact auditors ask for: "where did this dwh column
come from?" answered by one query.

Deterministic — pure reshaping of registry rows, no LLM.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from accelerator.phases.registry_builder import RegistryRow


@dataclass
class LineageRow:
    """The full raw -> std -> dwh path for one column."""

    lineage_id: str
    procedure_name: str
    raw_table: str
    raw_column: str
    raw_type: str
    std_table: str
    std_column: str
    std_type: str
    std_transform: str
    dwh_table: str
    dwh_column: str
    dwh_type: str
    dwh_transform: str
    is_business_key: bool
    is_scd2_tracked: bool
    generated_on: str

    def to_dict(self) -> dict:
        return asdict(self)


class LineageBuilder:
    """Builds lineage rows from registry rows."""

    def __init__(self, catalog: str = "hackathon"):
        self.catalog = catalog

    def build(
        self,
        registry_rows: list[RegistryRow],
        business_keys: dict[str, list[str]] | None = None,
        scd2_columns: dict[str, list[str]] | None = None,
    ) -> list[LineageRow]:
        """
        Pair up std and dwh registry rows for the same source column.

        business_keys / scd2_columns are keyed by procedure name and come
        from the parsed IR, so the lineage records which columns identify
        a row and which ones trigger a new SCD2 version.
        """
        business_keys = business_keys or {}
        scd2_columns = scd2_columns or {}
        now = datetime.now(timezone.utc).isoformat()

        # Index rows by (procedure, source table, source column) -> {layer: row}.
        # The procedure MUST be part of the key: different procedures share
        # source columns (cust_id appears in several), and without the
        # procedure in the key, later procedures overwrite earlier ones and
        # their lineage is lost.
        index: dict[tuple[str, str, str], dict[str, RegistryRow]] = {}
        for r in registry_rows:
            key = (
                r.procedure_name,
                f"{r.source_schema}.{r.source_table}",
                r.source_column.lower(),
            )
            index.setdefault(key, {})[r.target_layer] = r

        lineage: list[LineageRow] = []
        for (proc_key, src_table, src_col), layers in index.items():
            # dwh is the anchor: a column that never reaches dwh has no
            # meaningful lineage to record.
            dwh = layers.get("dwh")
            if dwh is None:
                continue
            std = layers.get("std")

            proc = dwh.procedure_name
            bk = {c.lower() for c in business_keys.get(proc, [])}
            scd = {c.lower() for c in scd2_columns.get(proc, [])}

            table_leaf = src_table.split(".")[-1]
            raw_fq = f"{self.catalog}.raw.{table_leaf}"

            # A derived column has no raw origin — it is computed in the
            # dwh layer, so its raw/std slots stay empty and the
            # derivation is recorded as the dwh transform.
            if dwh.is_derived:
                raw_col = ""
                raw_type = ""
                std_table = std_col = std_type = std_transform = ""
                dwh_transform = dwh.derivation_logic or "derived"
            else:
                raw_col = dwh.source_column
                raw_type = dwh.source_type or dwh.target_type
                std_table = (
                    f"{self.catalog}.std.{std.target_table}" if std else ""
                )
                std_col = std.target_column if std else ""
                std_type = std.target_type if std else ""
                std_transform = (std.transform_rule if std else "") or "rename+cast"
                dwh_transform = "passthrough"

            key_str = f"{proc}|{src_table}|{src_col}"
            lineage.append(
                LineageRow(
                    lineage_id=hashlib.sha256(key_str.encode()).hexdigest()[:16],
                    procedure_name=proc,
                    raw_table=raw_fq if raw_col else "",
                    raw_column=raw_col,
                    raw_type=raw_type,
                    std_table=std_table,
                    std_column=std_col,
                    std_type=std_type,
                    std_transform=std_transform,
                    dwh_table=f"{self.catalog}.dwh.{dwh.target_table}",
                    dwh_column=dwh.target_column,
                    dwh_type=dwh.target_type,
                    dwh_transform=dwh_transform,
                    is_business_key=src_col in bk,
                    is_scd2_tracked=src_col in scd,
                    generated_on=now,
                )
            )

        return lineage


def lineage_for_procedure(
    lineage: list[LineageRow], procedure_name: str
) -> list[LineageRow]:
    """
    Filter lineage rows down to one procedure — used by codegen.

    Procedure names can arrive with or without the schema prefix
    (``dbo.usp_Load_Dim_Customer`` from the parser IR vs
    ``usp_Load_Dim_Customer`` stored by the registry builder). Match on
    the bare procedure name (last dotted segment, lowercased) so the two
    forms line up and codegen actually finds its lineage.
    """
    def bare(name: str) -> str:
        return name.split(".")[-1].strip().lower()

    target = bare(procedure_name)
    return [l for l in lineage if bare(l.procedure_name) == target]
