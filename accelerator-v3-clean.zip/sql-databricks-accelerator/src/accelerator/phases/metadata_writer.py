"""
Metadata writer + run logger
=====================================================================
Persists every phase's output to the Databricks metadata schema, and
mirrors each artifact to a CSV under outputs/ so the pipeline is fully
inspectable without a warehouse connection.

All four metadata tables are APPEND-only. Rows carry deterministic ids
(registry_id, drift_id, lineage_id), so a rerun that finds the same
facts can be de-duplicated on those ids rather than wiping history.

Every phase writes an execution_log row: which run, which phase, which
procedure, status, row counts, duration. That is the audit trail for
"what did the accelerator actually do, and when".
"""

from __future__ import annotations

import csv
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

from accelerator.connections import DatabricksClient


def new_run_id() -> str:
    """One id per accelerator invocation, stamped on every log row."""
    return f"run_{datetime.now(timezone.utc):%Y%m%d_%H%M%S}_{uuid.uuid4().hex[:6]}"


def _sql_literal(value: Any) -> str:
    """Render a Python value as a SQL literal, safely quoted."""
    if value is None or value == "":
        return "NULL"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value).replace("'", "''")
    return f"'{text}'"


def _is_timestamp_field(name: str) -> bool:
    """Columns the metadata DDL declares as TIMESTAMP."""
    return name in {
        "generated_on", "detected_on", "reviewed_on",
        "started_at", "ended_at",
    }


class MetadataWriter:
    """Writes phase artifacts to Databricks and to local CSV."""

    def __init__(
        self,
        output_dir: Path,
        db: DatabricksClient | None = None,
        catalog: str = "hackathon",
        schema: str = "metadata",
    ):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.db = db
        self.catalog = catalog
        self.schema = schema

    # -- CSV mirror ----------------------------------------------------
    def write_csv(self, filename: str, rows: Sequence[dict]) -> str | None:
        """
        Mirror rows to outputs/<filename>. Appends if the file exists so
        the local artifact accumulates the same way the Delta table does.
        """
        if not rows:
            return None

        path = self.output_dir / filename
        exists = path.exists()

        with path.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            if not exists:
                writer.writeheader()
            writer.writerows(rows)

        return str(path)

    # -- Delta append --------------------------------------------------
    def write_table(self, table: str, rows: Sequence[dict]) -> int:
        """
        Append rows to a metadata Delta table. No-ops when running
        offline (db is None), so the whole pipeline works without a
        warehouse.
        """
        if self.db is None or not rows:
            return 0

        fq_table = f"{self.catalog}.{self.schema}.{table}"
        columns = list(rows[0].keys())
        col_list = ", ".join(columns)

        # Batch the inserts — one statement per 100 rows keeps the SQL
        # under warehouse statement-size limits.
        written = 0
        for start in range(0, len(rows), 100):
            chunk = rows[start : start + 100]
            values = []
            for row in chunk:
                rendered = []
                for c in columns:
                    lit = _sql_literal(row.get(c))
                    # Delta needs an explicit cast for ISO timestamp strings
                    if _is_timestamp_field(c) and lit != "NULL":
                        lit = f"CAST({lit} AS TIMESTAMP)"
                    rendered.append(lit)
                values.append("(" + ", ".join(rendered) + ")")

            self.db.execute(
                f"INSERT INTO {fq_table} ({col_list}) VALUES "
                + ", ".join(values)
            )
            written += len(chunk)

        return written

    # -- execution log -------------------------------------------------
    def log_run(
        self,
        run_id: str,
        phase: str,
        procedure_name: str,
        status: str,
        rows_affected: int = 0,
        message: str = "",
        started_at: datetime | None = None,
        ended_at: datetime | None = None,
        executed_by: str = "accelerator",
    ) -> None:
        """
        Append one execution_log row. Also echoes to stdout so the
        console transcript and the table tell the same story.
        """
        started = started_at or datetime.now(timezone.utc)
        ended = ended_at or datetime.now(timezone.utc)
        duration = (ended - started).total_seconds()

        record = {
            "run_id": run_id,
            "phase": phase,
            "procedure_name": procedure_name,
            "status": status,
            "rows_affected": rows_affected,
            "message": message,
            "started_at": started.isoformat(),
            "ended_at": ended.isoformat(),
            "duration_seconds": round(duration, 3),
            "executed_by": executed_by,
        }

        self.write_csv("execution_log.csv", [record])
        try:
            self.write_table("execution_log", [record])
        except Exception as exc:  # logging must never break the pipeline
            print(f"  (warn) could not write execution_log to Databricks: {exc}")

    # -- convenience: ensure tables exist ------------------------------
    def ensure_tables(self) -> None:
        """
        Create the metadata tables if the one-time script hasn't been run.
        Makes the accelerator self-sufficient on a fresh workspace.
        """
        if self.db is None:
            return

        self.db.execute(
            f"CREATE SCHEMA IF NOT EXISTS {self.catalog}.{self.schema}"
        )
        ddl = {
            "schema_registry": """
                registry_id STRING, source_system STRING, source_dialect STRING,
                procedure_name STRING, source_schema STRING, source_table STRING,
                source_column STRING, source_type STRING, target_layer STRING,
                target_schema STRING, target_table STRING, target_column STRING,
                target_type STRING, transform_rule STRING, is_derived BOOLEAN,
                derivation_logic STRING, generated_on TIMESTAMP, generated_by STRING
            """,
            "schema_drift": """
                drift_id STRING, detected_on TIMESTAMP, procedure_name STRING,
                source_table STRING, raw_table STRING, column_name STRING,
                drift_type STRING, expected_value STRING, actual_value STRING,
                severity STRING, resolution_mode STRING, review_status STRING,
                reviewed_by STRING, reviewed_on TIMESTAMP, reviewer_notes STRING
            """,
            "lineage": """
                lineage_id STRING, procedure_name STRING, raw_table STRING,
                raw_column STRING, raw_type STRING, std_table STRING,
                std_column STRING, std_type STRING, std_transform STRING,
                dwh_table STRING, dwh_column STRING, dwh_type STRING,
                dwh_transform STRING, is_business_key BOOLEAN,
                is_scd2_tracked BOOLEAN, generated_on TIMESTAMP
            """,
            "execution_log": """
                run_id STRING, phase STRING, procedure_name STRING,
                status STRING, rows_affected BIGINT, message STRING,
                started_at TIMESTAMP, ended_at TIMESTAMP,
                duration_seconds DOUBLE, executed_by STRING
            """,
        }
        for table, cols in ddl.items():
            self.db.execute(
                f"CREATE TABLE IF NOT EXISTS "
                f"{self.catalog}.{self.schema}.{table} ({cols}) USING DELTA"
            )
