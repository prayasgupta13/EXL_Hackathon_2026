"""
PHASE 2 — Drift Detector
=====================================================================
Compares the GENERATED registry against the ACTUAL raw-layer schema in
Databricks and records every mismatch.

This is real detection, not a pre-seeded narrative. Rows appear in
metadata.schema_drift only because a live comparison found a live gap:

  MISSING_TABLE   the procedure reads a table the raw layer doesn't have
  MISSING_COLUMN  the procedure uses a column absent from the raw table
  TYPE_MISMATCH   raw landed a different type than the procedure implies
  EXTRA_COLUMN    raw has a column no procedure references (informational)

Severity drives the pipeline:
  BLOCKER  -> code generation for that procedure is stopped
  WARNING  -> generation proceeds, finding is logged for review

Fully deterministic — no LLM. A drift finding must be reproducible and
explainable ("raw has STRING, the procedure implies DECIMAL(18,2)").
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, asdict
from datetime import datetime, timezone

from accelerator.connections import DatabricksClient
from accelerator.phases.registry_builder import RegistryRow
from accelerator.utils import naming


@dataclass
class DriftFinding:
    """One detected mismatch between the registry and the raw layer."""

    drift_id: str
    detected_on: str
    procedure_name: str
    source_table: str
    raw_table: str
    column_name: str
    drift_type: str        # MISSING_TABLE / MISSING_COLUMN / TYPE_MISMATCH / EXTRA_COLUMN
    expected_value: str
    actual_value: str
    severity: str          # BLOCKER / WARNING
    resolution_mode: str   # AUTO / APPROVAL_REQUIRED
    review_status: str = "OPEN"
    reviewed_by: str = ""
    reviewed_on: str = ""
    reviewer_notes: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class DriftDetector:
    """Compares registry expectations against the live raw layer."""

    def __init__(self, db: DatabricksClient, catalog: str = "hackathon"):
        self.db = db
        self.catalog = catalog
        # Cache raw schemas so we DESCRIBE each table once per run.
        self._schema_cache: dict[str, list[dict] | None] = {}

    # -----------------------------------------------------------------
    def detect(self, registry_rows: list[RegistryRow]) -> list[DriftFinding]:
        """
        Compare every distinct source table in the registry against its
        raw-layer counterpart. Returns all findings.
        """
        findings: list[DriftFinding] = []

        # Group registry rows by source table (std rows only — one row per
        # source column is enough; dwh rows repeat the same source columns).
        by_table: dict[str, list[RegistryRow]] = {}
        for r in registry_rows:
            if r.target_layer != "std":
                continue
            key = f"{r.source_schema}.{r.source_table}"
            by_table.setdefault(key, []).append(r)

        for source_table, rows in by_table.items():
            findings.extend(self._check_table(source_table, rows))

        return findings

    # -----------------------------------------------------------------
    def _check_table(
        self, source_table: str, rows: list[RegistryRow]
    ) -> list[DriftFinding]:
        """Check one source table against its raw counterpart."""
        findings: list[DriftFinding] = []
        now = datetime.now(timezone.utc).isoformat()

        table_leaf = source_table.split(".")[-1]
        raw_fq = f"{self.catalog}.raw.{table_leaf}"
        procedure = rows[0].procedure_name

        raw_schema = self._raw_schema(raw_fq)

        # ---- MISSING_TABLE -------------------------------------------
        if raw_schema is None:
            findings.append(
                self._finding(
                    now, procedure, source_table, raw_fq, "",
                    "MISSING_TABLE",
                    expected=f"table {raw_fq} referenced by {procedure}",
                    actual="table does not exist in the raw layer",
                    severity="BLOCKER",
                    resolution="APPROVAL_REQUIRED",
                )
            )
            return findings  # nothing further to compare

        raw_cols = {c["name"].lower(): c["type"].lower() for c in raw_schema}

        # ---- MISSING_COLUMN / TYPE_MISMATCH --------------------------
        registry_cols: set[str] = set()
        for r in rows:
            if r.is_derived:
                continue  # derived columns are computed, not landed in raw
            col = r.source_column.lower()
            registry_cols.add(col)

            if col not in raw_cols:
                findings.append(
                    self._finding(
                        now, procedure, source_table, raw_fq, r.source_column,
                        "MISSING_COLUMN",
                        expected=(
                            f"{r.source_column} "
                            f"({r.source_type or r.target_type})"
                        ),
                        actual="column not present in raw table",
                        severity="BLOCKER",
                        resolution="APPROVAL_REQUIRED",
                    )
                )
                continue

            # Type comparison: what the procedure implies vs what raw has.
            expected_type = r.target_type.lower()
            actual_type = raw_cols[col]
            if not self._types_compatible(expected_type, actual_type):
                findings.append(
                    self._finding(
                        now, procedure, source_table, raw_fq, r.source_column,
                        "TYPE_MISMATCH",
                        expected=expected_type,
                        actual=actual_type,
                        # A widening (string holding a number) is recoverable
                        # with a cast, so it is a WARNING, not a BLOCKER.
                        severity="WARNING",
                        resolution="APPROVAL_REQUIRED",
                    )
                )

        # ---- EXTRA_COLUMN (informational) ----------------------------
        for col, typ in raw_cols.items():
            if col in registry_cols or naming.is_audit_column(col):
                continue
            findings.append(
                self._finding(
                    now, procedure, source_table, raw_fq, col,
                    "EXTRA_COLUMN",
                    expected="not referenced by any procedure",
                    actual=f"present in raw as {typ}",
                    severity="WARNING",
                    # New source columns can be adopted automatically —
                    # they extend the target, they don't break it.
                    resolution="AUTO",
                )
            )

        return findings

    # -----------------------------------------------------------------
    def _raw_schema(self, raw_fq: str) -> list[dict] | None:
        """
        DESCRIBE a raw table, cached. Returns None when the table does
        not exist (that is itself a finding, not an error).
        """
        if raw_fq in self._schema_cache:
            return self._schema_cache[raw_fq]

        try:
            schema = self.db.table_schema(raw_fq)
        except Exception:
            # Any failure to describe is treated as "table not available".
            schema = None

        self._schema_cache[raw_fq] = schema
        return schema

    @staticmethod
    def _types_compatible(expected: str, actual: str) -> bool:
        """
        Are the two Spark types close enough not to flag?

        Exact match passes. Integer widths are treated as compatible
        (int vs bigint is not worth a review). Everything else, including
        the important string-vs-decimal case, is a mismatch.
        """
        if expected == actual:
            return True

        integer_family = {"int", "integer", "bigint", "smallint", "tinyint"}
        if expected in integer_family and actual in integer_family:
            return True

        # date vs timestamp: both temporal, and date->timestamp is a safe
        # widening. Not worth flagging — the std cast handles it.
        temporal_family = {"date", "timestamp"}
        if expected in temporal_family and actual in temporal_family:
            return True

        # decimal(18,2) vs decimal(20,4): same family, different precision.
        # Flag it — precision changes can silently truncate.
        return False

    @staticmethod
    def _finding(
        now, procedure, source_table, raw_table, column,
        drift_type, expected, actual, severity, resolution,
    ) -> DriftFinding:
        """Build a finding with a deterministic id so reruns dedupe."""
        key = f"{procedure}|{source_table}|{column}|{drift_type}"
        drift_id = hashlib.sha256(key.encode()).hexdigest()[:16]
        return DriftFinding(
            drift_id=drift_id,
            detected_on=now,
            procedure_name=procedure,
            source_table=source_table,
            raw_table=raw_table,
            column_name=column,
            drift_type=drift_type,
            expected_value=expected,
            actual_value=actual,
            severity=severity,
            resolution_mode=resolution,
        )


def blocking_procedures(findings: list[DriftFinding]) -> set[str]:
    """
    Procedures that must NOT proceed to code generation because a
    BLOCKER-severity drift was found against a table they read.
    """
    return {f.procedure_name for f in findings if f.severity == "BLOCKER"}
