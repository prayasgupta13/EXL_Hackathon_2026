"""
PHASE 0 — Procedure Parser
=====================================================================
Turns a raw stored-procedure .sql file into a structured ProcedureIR.

Design: DETERMINISTIC FIRST, LLM SECOND.
  - sqlglot does the mechanical work that must be repeatable: dialect
    parsing, spotting dynamic SQL / cursors, listing referenced tables.
  - Claude then fills in the semantic layer that is hard to do with
    rules alone: load pattern (SCD2 vs fact), business keys, the intent
    of each transformation.
This split is the "rule-based transforms alongside LLM" recommendation:
the risky, must-be-correct detections are rules; the LLM handles nuance.

If sqlglot flags an unsupported construct, we still return an IR — but
with `unsupported` populated, so the orchestrator routes the procedure
to human review instead of generating code.
"""

from __future__ import annotations

import re

import sqlglot
from sqlglot import exp

from accelerator.connections import LLMClient
from accelerator.ir import (
    ProcedureIR,
    UnsupportedConstruct,
    UnsupportedReason,
    LoadPattern,
)

# System prompt for the LLM pass. Kept as a module constant so it is
# easy to review, version, and audit.
_IR_SYSTEM_PROMPT = """\
You are a SQL analysis agent. You receive a single SQL Server (T-SQL)
stored procedure and a list of the tables it references (already
extracted deterministically). Return ONLY a JSON object describing it.

The JSON must have exactly these keys:
  procedure_name: string
  dialect: "tsql"
  source_tables: string[]        (schema-qualified, e.g. "dbo.stg_customer")
  target_table: string|null      (the table being loaded)
  load_pattern: "scd2"|"fact_append"|"full_refresh"|"unknown"
  business_key: string[]         (columns identifying a row; [] if none)
  scd_compare_columns: string[]  (columns whose change triggers a new SCD2 version; [] if not scd2)
  columns: [{name: string, source_table: string|null}]
  joins: [{left_table, right_table, join_type, on_condition}]
  filters: string[]              (WHERE predicates, as text)
  transformations: [{output_column, expression, description}]

Rules:
- load_pattern is "scd2" if the proc expires current rows and inserts
  new versions with effective dates. It is "fact_append" if it does an
  idempotent insert into a fact table (anti-join on a business key).
- Do NOT include unsupported constructs (dynamic SQL, cursors) here;
  those are handled separately.
- Output raw JSON only. No markdown fences, no prose.
"""


class ProcedureParser:
    """Parses one stored procedure into a ProcedureIR."""

    def __init__(self, llm: LLMClient, dialect: str = "tsql"):
        self.llm = llm
        self.dialect = dialect  # provided by the Dialect ID stub upstream

    def parse(self, procedure_sql: str) -> ProcedureIR:
        """
        Parse a single CREATE PROCEDURE statement.
        Returns a ProcedureIR whose `unsupported` list is non-empty if
        the procedure contains constructs we won't auto-convert.
        """
        # --- 1. Deterministic detection of unsupported constructs -----
        unsupported = self._detect_unsupported(procedure_sql)

        # --- 2. Deterministic extraction of referenced tables ---------
        source_tables = self._extract_tables(procedure_sql)
        proc_name = self._extract_proc_name(procedure_sql)

        # If we already know it's not convertible, we can skip the LLM
        # semantic pass entirely — no point analysing code we'll route
        # to a human. This also saves tokens.
        if unsupported:
            return ProcedureIR(
                procedure_name=proc_name,
                dialect=self.dialect,
                source_tables=source_tables,
                unsupported=unsupported,
            )

        # --- 3. LLM semantic pass -------------------------------------
        user_msg = (
            f"Referenced tables (from static analysis): {source_tables}\n\n"
            f"Procedure:\n```sql\n{procedure_sql}\n```"
        )
        raw = self.llm.complete_json(_IR_SYSTEM_PROMPT, user_msg)

        # Work on a copy — never mutate what the client handed back, so
        # callers (and tests) can safely reuse the object.
        data = dict(raw)

        # Trust the deterministic table list over the LLM's if they differ;
        # static analysis is more reliable for "which tables exist".
        data["source_tables"] = source_tables or data.get("source_tables", [])
        data.setdefault("procedure_name", proc_name)
        data.setdefault("dialect", self.dialect)

        ir = ProcedureIR.from_dict(data)
        return ir

    # -- deterministic helpers ---------------------------------------
    def _detect_unsupported(self, sql: str) -> list[UnsupportedConstruct]:
        """
        Rule-based scan for constructs we deliberately don't auto-convert.
        These checks are intentionally simple and conservative: a false
        positive routes to human review (safe); a false negative would
        generate wrong code (unsafe). We err toward flagging.
        """
        found: list[UnsupportedConstruct] = []

        # Dynamic SQL: EXEC(...) or sp_executesql over a built string.
        if re.search(r"\bsp_executesql\b", sql, re.IGNORECASE) or re.search(
            r"\bEXEC\s*\(", sql, re.IGNORECASE
        ):
            snippet = self._first_match(
                sql, r"(EXEC\s*\(|EXEC(?:UTE)?\s+sp_executesql).{0,80}"
            )
            found.append(
                UnsupportedConstruct(
                    reason=UnsupportedReason.DYNAMIC_SQL,
                    snippet=snippet,
                    note="Dynamic SQL builds statements at runtime; the "
                    "target table/columns aren't statically known, so we "
                    "route this to human review rather than guess.",
                )
            )

        # Cursors: DECLARE ... CURSOR / FETCH NEXT.
        if re.search(r"\bDECLARE\b[^;]{0,120}\bCURSOR\b", sql, re.IGNORECASE):
            found.append(
                UnsupportedConstruct(
                    reason=UnsupportedReason.CURSOR,
                    snippet=self._first_match(sql, r"DECLARE\b.{0,80}CURSOR"),
                    note="Row-by-row cursor logic should be rewritten as a "
                    "set-based Spark operation by a human.",
                )
            )

        return found

    def _extract_tables(self, sql: str) -> list[str]:
        """
        Use sqlglot to list every table the procedure reads or writes.
        Falls back gracefully: if sqlglot can't parse a fragment (T-SQL
        procedural syntax isn't fully supported), we regex the FROM/JOIN/
        INTO/UPDATE targets so we still get a usable table list.
        """
        tables: set[str] = set()

        # sqlglot's T-SQL dialect parses most statements; procedural
        # wrappers (BEGIN/END, DECLARE) may not parse as one tree, so we
        # split on GO/semicolons and parse best-effort.
        for stmt in re.split(r"\bGO\b|;", sql):
            stmt = stmt.strip()
            if not stmt:
                continue
            try:
                for parsed in sqlglot.parse(stmt, read="tsql"):
                    if parsed is None:
                        continue
                    for tbl in parsed.find_all(exp.Table):
                        tables.add(self._qualify(tbl))
            except Exception:
                # best-effort regex fallback for this fragment
                tables.update(self._regex_tables(stmt))

        # Always run the regex fallback too and union — belt and braces,
        # since procedural T-SQL trips sqlglot on some fragments.
        tables.update(self._regex_tables(sql))

        # Drop temp tables (#name), system/stored-procedure names, and
        # anything empty. Without this, EXEC targets like sp_executesql and
        # the procedure's own name leak into the "source tables" list.
        proc_name = self._extract_proc_name(sql).lower()
        noise_prefixes = ("sp_", "usp_", "xp_")

        def _is_table(name: str) -> bool:
            if not name or name.lstrip().startswith("#"):
                return False
            if name.lower() == proc_name:
                return False
            leaf = name.split(".")[-1].lower()
            return not leaf.startswith(noise_prefixes)

        clean = sorted(t for t in tables if _is_table(t))
        return clean

    @staticmethod
    def _qualify(tbl: exp.Table) -> str:
        """Render a sqlglot Table node as 'schema.table' where possible."""
        parts = [p for p in (tbl.db, tbl.name) if p]
        return ".".join(parts)

    @staticmethod
    def _regex_tables(sql: str) -> set[str]:
        """Regex fallback: pull tables after FROM/JOIN/INTO/UPDATE."""
        pattern = r"\b(?:FROM|JOIN|INTO|UPDATE)\s+(\[?\w+\]?\.\[?\w+\]?)"
        return {
            m.group(1).replace("[", "").replace("]", "")
            for m in re.finditer(pattern, sql, re.IGNORECASE)
        }

    @staticmethod
    def _extract_proc_name(sql: str) -> str:
        """Pull the procedure name from CREATE [OR ALTER] PROCEDURE."""
        m = re.search(
            r"CREATE\s+(?:OR\s+ALTER\s+)?PROC(?:EDURE)?\s+(\[?\w+\]?\.?\[?\w+\]?)",
            sql,
            re.IGNORECASE,
        )
        return m.group(1).replace("[", "").replace("]", "") if m else "unknown_proc"

    @staticmethod
    def _first_match(sql: str, pattern: str) -> str:
        """Return the first regex match (single-lined) or empty string."""
        m = re.search(pattern, sql, re.IGNORECASE | re.DOTALL)
        return " ".join(m.group(0).split()) if m else ""
