"""
PHASE 5 — Workspace Uploader
=====================================================================
Uploads the notebooks generated in Phase 4 into the Databricks
workspace, so they land as runnable notebooks instead of only sitting
in the local outputs/generated/ folder. Closes the loop:
    generate (local) -> upload (workspace) -> run (Databricks).

Auth: reuses the same host + PAT already in .env (the ones the
DatabricksClient uses), via the Databricks SDK's WorkspaceClient.

Target: /Workspace/Users/accelerator_output/<procedure>/<layer>_notebook
Each procedure gets its own sub-folder; each .py becomes a Python
notebook (SOURCE import with language=PYTHON).
"""

from __future__ import annotations

import base64
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


@dataclass
class UploadResult:
    """Outcome of uploading one notebook."""

    local_path: str
    workspace_path: str
    ok: bool
    message: str = ""


class WorkspaceUploader:
    """Imports generated .py notebooks into the Databricks workspace."""

    def __init__(self, base_dir: str | None=None):
        """
        base_dir defaults to DATABRICKS_WORKSPACE_DIR env var, or
        /Workspace/Shared/accelerator_output
        """
        import os
        if base_dir is None:
            base_dir = os.getenv(
                "DATABRICKS_WORKSPACE_DIR",
                "/Workspace/Shared/accelerator_output"
            )
        self.base_dir = base_dir.rstrip("/")
        self._client = None

    # -----------------------------------------------------------------
    def connect(self) -> None:
        """
        Build a WorkspaceClient from the same .env credentials the rest
        of the accelerator uses. Deferred import keeps the SDK optional.
        """
        from databricks.sdk import WorkspaceClient  # deferred import

        load_dotenv()
        host = os.getenv("DATABRICKS_HOST", "").replace("https://", "").rstrip("/")
        token = os.getenv("DATABRICKS_TOKEN")
        if not host or not token:
            raise EnvironmentError(
                "DATABRICKS_HOST / DATABRICKS_TOKEN missing from .env — "
                "cannot upload to the workspace."
            )
        # SDK wants the full https:// host.
        self._client = WorkspaceClient(host=f"https://{host}", token=token)

    # -----------------------------------------------------------------
    def upload_generated(self, generated_dir: str | Path) -> list[UploadResult]:
        """
        Walk outputs/generated/<proc>/*.py and import each into the
        workspace under base_dir/<proc>/<name>. Returns one result per
        file so the caller can log successes and failures.
        """
        from databricks.sdk.service.workspace import ImportFormat, Language

        if self._client is None:
            self.connect()

        results: list[UploadResult] = []
        gen_dir = Path(generated_dir)
        if not gen_dir.is_dir():
            return results

        # Ensure the base folder exists (mkdirs is idempotent).
        self._client.workspace.mkdirs(self.base_dir)

        for proc_dir in sorted(p for p in gen_dir.iterdir() if p.is_dir()):
            proc_ws_dir = f"{self.base_dir}/{proc_dir.name}"
            self._client.workspace.mkdirs(proc_ws_dir)

            for py_file in sorted(proc_dir.glob("*.py")):
                # Notebook name without extension — Databricks adds its own.
                nb_name = py_file.stem
                ws_path = f"{proc_ws_dir}/{nb_name}"

                try:
                    content = py_file.read_text(encoding="utf-8")
                    encoded = base64.b64encode(content.encode("utf-8")).decode()

                    # overwrite=True so re-runs replace the previous version
                    # instead of erroring on an existing path.
                    self._client.workspace.import_(
                        path=ws_path,
                        format=ImportFormat.SOURCE,
                        language=Language.PYTHON,
                        content=encoded,
                        overwrite=True,
                    )
                    results.append(
                        UploadResult(str(py_file), ws_path, True)
                    )
                except Exception as exc:  # one bad file shouldn't stop the rest
                    results.append(
                        UploadResult(str(py_file), ws_path, False, str(exc))
                    )

        return results
