"""
Intermediate Representation (IR) for a parsed stored procedure.
=====================================================================
This is the deterministic backbone the Stage-1 feedback asked for:
"a deterministic intermediate representation (AST/relational algebra)
... to improve repeatability and auditability."

Every agent after the Parser speaks in terms of these dataclasses, not
raw SQL text. That makes the pipeline testable (you can assert on an IR
object) and auditable (you can serialize the IR to JSON and inspect it).

Flow:
    raw .sql  --Parser/IR Agent-->  ProcedureIR  --downstream agents-->
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
import json


class LoadPattern(str, Enum):
    """The high-level shape of what a procedure does."""

    SCD2 = "scd2"                # slowly-changing dimension, type 2
    FACT_APPEND = "fact_append"  # idempotent fact insert
    AGGREGATE = "aggregate"      # GROUP BY rollup into a fact
    FULL_REFRESH = "full_refresh"
    UNKNOWN = "unknown"

    @classmethod
    def _missing_(cls, value):
        """
        Never crash on an unexpected value from the model — fall back to
        UNKNOWN so the pipeline continues and the gap is visible in the
        generated artifacts rather than as a stack trace.
        """
        return cls.UNKNOWN


class UnsupportedReason(str, Enum):
    """Why a construct can't be auto-converted (drives human-in-the-loop)."""

    DYNAMIC_SQL = "dynamic_sql"      # EXEC sp_executesql — string-built SQL
    CURSOR = "cursor"
    UNSUPPORTED_FUNCTION = "unsupported_function"
    UNKNOWN_CONSTRUCT = "unknown_construct"


@dataclass
class ColumnRef:
    """A column referenced in the procedure, with its source table."""

    name: str
    source_table: str | None = None  # e.g. 'dbo.stg_customer'


@dataclass
class JoinClause:
    """One join between two tables."""

    left_table: str
    right_table: str
    join_type: str          # INNER / LEFT / RIGHT / FULL
    on_condition: str       # kept as text; downstream maps column names


@dataclass
class Transformation:
    """A derived / transformed column (CASE, DATEDIFF, ISNULL, etc.)."""

    output_column: str
    expression: str         # source expression, verbatim from the proc
    description: str = ""    # plain-language note from the parser


@dataclass
class UnsupportedConstruct:
    """
    A construct the parser recognised but cannot safely convert.
    Its presence forces the procedure onto the human-in-the-loop path
    instead of silently producing wrong code.
    """

    reason: UnsupportedReason
    snippet: str            # the offending SQL text
    note: str = ""


@dataclass
class ProcedureIR:
    """
    The full parsed representation of one stored procedure.
    This object is the contract handed from the Parser to every
    downstream agent.
    """

    procedure_name: str
    dialect: str                                   # 'tsql', 'plsql', ...
    source_tables: list[str] = field(default_factory=list)
    target_table: str | None = None
    load_pattern: LoadPattern = LoadPattern.UNKNOWN

    # SCD2 specifics (populated only when load_pattern == SCD2)
    business_key: list[str] = field(default_factory=list)
    scd_compare_columns: list[str] = field(default_factory=list)

    columns: list[ColumnRef] = field(default_factory=list)
    joins: list[JoinClause] = field(default_factory=list)
    filters: list[str] = field(default_factory=list)         # WHERE predicates
    transformations: list[Transformation] = field(default_factory=list)
    unsupported: list[UnsupportedConstruct] = field(default_factory=list)

    @property
    def is_convertible(self) -> bool:
        """
        True only if the parser found NO unsupported constructs.
        The orchestrator checks this to decide auto-convert vs. route
        to human review.
        """
        return len(self.unsupported) == 0

    def to_json(self, indent: int = 2) -> str:
        """Serialise the IR for logging / the lineage report / tests."""
        return json.dumps(asdict(self), indent=indent, default=str)

    @classmethod
    def from_dict(cls, data: dict) -> "ProcedureIR":
        """
        Rebuild a ProcedureIR from the JSON the Parser/IR Agent returns.
        Nested dataclasses are reconstructed explicitly so downstream
        code gets real typed objects, not plain dicts.
        """
        return cls(
            procedure_name=data["procedure_name"],
            dialect=data.get("dialect", "tsql"),
            source_tables=data.get("source_tables", []),
            target_table=data.get("target_table"),
            load_pattern=LoadPattern(data.get("load_pattern", "unknown")),
            business_key=data.get("business_key", []),
            scd_compare_columns=data.get("scd_compare_columns", []),
            columns=[ColumnRef(**c) for c in data.get("columns", [])],
            joins=[JoinClause(**j) for j in data.get("joins", [])],
            filters=data.get("filters", []),
            transformations=[
                Transformation(**t) for t in data.get("transformations", [])
            ],
            unsupported=[
                UnsupportedConstruct(
                    reason=UnsupportedReason(u["reason"]),
                    snippet=u["snippet"],
                    note=u.get("note", ""),
                )
                for u in data.get("unsupported", [])
            ],
        )
