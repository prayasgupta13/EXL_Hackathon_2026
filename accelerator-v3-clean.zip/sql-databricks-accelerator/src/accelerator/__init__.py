"""GenAI SQL Procedure -> Databricks Migration Accelerator (v3)."""
__version__ = "3.0.0"
