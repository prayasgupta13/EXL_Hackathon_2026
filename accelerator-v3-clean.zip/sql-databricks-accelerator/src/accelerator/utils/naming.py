"""
Naming convention engine — DETERMINISTIC.
=====================================================================
Derives standardised target names from abbreviated source names, e.g.

    cust_nm      -> customer_name
    pol_start_dt -> policy_start_date
    claim_amt    -> claim_amount
    stg_customer -> customer          (std layer)
    dim_customer -> dim_customer      (dwh layer keeps its prefix)

This is rule-based on purpose. Name derivation must produce the SAME
answer on every run, or the registry (and every downstream artifact)
becomes unstable. The LLM is only consulted for tokens this dictionary
cannot expand, and any LLM-derived expansion is recorded with a lower
confidence so a human can review it.
"""

from __future__ import annotations

import re

# ---------------------------------------------------------------------
# Abbreviation dictionary. Extend this rather than special-casing in
# code — it is the single place naming rules live.
# ---------------------------------------------------------------------
ABBREVIATIONS: dict[str, str] = {
    "cust": "customer",
    "pol": "policy",
    "nm": "name",
    "addr": "address",
    "seg": "segment",
    "dt": "date",
    "ts": "timestamp",
    "amt": "amount",
    "sts": "status",
    "typ": "type",
    "no": "number",
    "num": "number",
    "cnt": "count",
    "qty": "quantity",
    "desc": "description",
    "eff": "effective",
    "curr": "current",
    "prem": "premium",
    "txn": "transaction",
    "sk": "sk",            # surrogate key — keep as-is, it's a convention
    "id": "id",            # already clear
    "flag": "flag",
    "prod": "product",
    "acct": "account",
    "bal": "balance",
    "src": "source",
    "tgt": "target",
    "dob": "date_of_birth",
    "ph": "phone",
    "yr": "year",
    "mth": "month",
}

# Table-name prefixes that indicate a layer rather than being part of
# the business name.
TABLE_PREFIXES = {"stg", "tmp", "wrk", "raw"}

# SQL Server -> Spark type mapping. Deterministic; unknown types fall
# back to STRING with a warning recorded by the caller.
TYPE_MAP: dict[str, str] = {
    "INT": "int",
    "INTEGER": "int",
    "BIGINT": "bigint",
    "SMALLINT": "smallint",
    "TINYINT": "tinyint",
    "BIT": "boolean",
    "DATE": "date",
    "DATETIME": "timestamp",
    "DATETIME2": "timestamp",
    "SMALLDATETIME": "timestamp",
    "TIME": "string",
    "FLOAT": "double",
    "REAL": "float",
    "MONEY": "decimal(19,4)",
    "SYSNAME": "string",
    "UNIQUEIDENTIFIER": "string",
}


def expand_column(name: str) -> str:
    """
    Expand an abbreviated column name into its standardised form.

        cust_nm      -> customer_name
        pol_start_dt -> policy_start_date
        is_curr_flag -> is_current_flag

    Tokens not found in ABBREVIATIONS are passed through unchanged, so a
    fully-spelled name stays as it is.
    """
    tokens = re.split(r"[_\s]+", name.strip().lower())
    expanded = [ABBREVIATIONS.get(t, t) for t in tokens if t]
    return "_".join(expanded)


def unresolved_tokens(name: str) -> list[str]:
    """
    Return tokens that are neither in the dictionary nor plain words.
    The registry builder uses this to decide whether to ask the LLM and
    to lower the confidence on the resulting mapping.

    A token is 'suspicious' if it is short (<= 4 chars) and not a known
    abbreviation — likely an abbreviation we don't know yet.
    """
    tokens = re.split(r"[_\s]+", name.strip().lower())
    return [
        t
        for t in tokens
        if t and t not in ABBREVIATIONS and len(t) <= 4 and not t.isdigit()
    ]


def std_table_name(source_table: str) -> str:
    """
    Derive the std-layer table name from a source table name.

        dbo.stg_customer -> customer
        stg_premium_txn  -> premium_transaction

    Layer prefixes (stg_, tmp_) are stripped because the schema already
    conveys the layer.
    """
    leaf = source_table.split(".")[-1].lower()
    tokens = re.split(r"[_\s]+", leaf)
    if tokens and tokens[0] in TABLE_PREFIXES:
        tokens = tokens[1:]
    return "_".join(ABBREVIATIONS.get(t, t) for t in tokens if t)


def dwh_table_name(procedure_target: str | None, source_table: str) -> str:
    """
    Derive the dwh-layer table name.

    The procedure's own target table is the best signal — a procedure
    called usp_Load_Dim_Customer writes dbo.dim_customer, so the dwh
    table is dim_customer. dim_/fact_ prefixes are warehouse convention
    and are KEPT.

    Falls back to the std name if the procedure target is unknown.
    """
    if procedure_target:
        leaf = procedure_target.split(".")[-1].lower()
        tokens = re.split(r"[_\s]+", leaf)
        # keep dim_/fact_ prefix, expand the rest
        if tokens and tokens[0] in {"dim", "fact"}:
            head, rest = tokens[0], tokens[1:]
            return head + "_" + "_".join(
                ABBREVIATIONS.get(t, t) for t in rest if t
            )
        return "_".join(ABBREVIATIONS.get(t, t) for t in tokens if t)
    return std_table_name(source_table)


def map_type(sql_type: str | None) -> str:
    """
    Map a SQL Server type to its Spark equivalent.
    Parameterised types (VARCHAR(n), DECIMAL(p,s)) are handled by shape.
    Unknown types fall back to 'string'.
    """
    if not sql_type:
        return "string"

    t = sql_type.strip().upper()

    # DECIMAL(18,2) / NUMERIC(18,2) -> decimal(18,2)
    m = re.match(r"^(?:DECIMAL|NUMERIC)\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)$", t)
    if m:
        return f"decimal({m.group(1)},{m.group(2)})"

    # Any character type -> string, regardless of length
    if re.match(r"^N?(?:VAR)?CHAR\s*(\(.*\))?$", t):
        return "string"
    if "TEXT" in t:
        return "string"

    # Strip any parameterisation before dictionary lookup
    base = re.sub(r"\s*\(.*\)$", "", t)
    return TYPE_MAP.get(base, "string")


def refine_type_by_name(column: str, mapped_type: str) -> str:
    """
    Override the inferred type for columns whose NAME reliably implies a
    type, regardless of what the LLM guessed from usage.

    Why: a column used only in a JOIN (ON a.cust_id = b.cust_id) gives the
    model no numeric signal, so it may guess NVARCHAR/string. But an
    *_id / *_sk column is an integer key by convention. Enforcing that
    here — deterministically — removes false-positive type-drift findings
    (e.g. cust_id reported as string vs int in raw).

    Rules (name wins only for these well-established conventions):
      *_sk            -> bigint   (surrogate key)
      *_id / id       -> int      (natural/business key id)
      *_flag / is_*   -> boolean
      *_cnt / *_count -> bigint
    Everything else keeps the mapped_type unchanged.
    """
    n = column.strip().lower()

    if n.endswith("_sk"):
        return "bigint"
    if n == "id" or n.endswith("_id"):
        return "int"
    if n.endswith("_flag") or n.startswith("is_"):
        return "boolean"
    if n.endswith("_cnt") or n.endswith("_count"):
        return "bigint"
    return mapped_type


def is_audit_column(name: str) -> bool:
    """
    True for SCD2 / ETL housekeeping columns. These are OWNED by the dwh
    layer and generated by the pipeline, so they must not be treated as
    source columns or reported as drift when absent from raw.
    """
    n = name.strip().lower()
    audit = {
        "eff_start_dt", "eff_end_dt", "is_curr_flag",
        "effective_start_date", "effective_end_date", "is_current",
        "load_dt", "load_date", "_ingest_ts", "_source_file",
        "_std_load_ts", "created_dt", "updated_dt",
    }
    if n in audit:
        return True
    # surrogate keys (cust_sk, customer_sk, policy_sk)
    return n.endswith("_sk")
