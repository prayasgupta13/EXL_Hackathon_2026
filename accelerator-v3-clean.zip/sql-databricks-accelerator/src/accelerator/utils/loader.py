"""
Loads stored procedures from the input folder — one procedure per file.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class ProcedureFile:
    """A single .sql file containing one stored procedure."""

    path: Path
    sql: str

    @property
    def filename(self) -> str:
        return self.path.name


def load_procedures(folder: str | Path) -> list[ProcedureFile]:
    """
    Read every .sql file in the folder, sorted by filename so the run
    order is deterministic (hence the 01_, 02_ prefixes).
    """
    directory = Path(folder)
    if not directory.is_dir():
        raise NotADirectoryError(f"Procedure folder not found: {directory}")

    files = sorted(directory.glob("*.sql"))
    if not files:
        raise FileNotFoundError(f"No .sql files found in {directory}")

    return [
        ProcedureFile(path=f, sql=f.read_text(encoding="utf-8"))
        for f in files
    ]
