/* =====================================================================
   Procedure 4 of 5  —  Monthly premium fact aggregation
   Complexity : MEDIUM  (GROUP BY aggregation, join to dimension)
   Drift      : MISSING TABLE — reads dbo.stg_premium_txn, which has NOT
                been landed in the Databricks raw layer at all.
                Expected: flagged as a missing-table drift for human review.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_Load_Fact_Premium
    @BatchMonth CHAR(7)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.fact_premium
        (pol_no, cust_sk, txn_month, total_prem_amt, txn_cnt, load_dt)
    SELECT
        t.pol_no,
        dc.cust_sk,
        @BatchMonth                AS txn_month,
        SUM(t.txn_amt)             AS total_prem_amt,
        COUNT(*)                   AS txn_cnt,
        GETDATE()
    FROM dbo.stg_premium_txn t          -- DRIFT: table absent from raw layer
    INNER JOIN dbo.dim_customer dc
        ON t.cust_id = dc.cust_id AND dc.is_curr_flag = 1
    WHERE CONVERT(CHAR(7), t.txn_dt, 120) = @BatchMonth
      AND t.txn_sts = 'POSTED'
    GROUP BY t.pol_no, dc.cust_sk;
END
GO
