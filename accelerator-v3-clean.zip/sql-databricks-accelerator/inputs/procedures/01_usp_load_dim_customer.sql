/* =====================================================================
   Procedure 1 of 5  —  SCD Type 2 customer dimension load
   Complexity : LOW
   Drift      : NONE (clean baseline — everything it references exists in raw)
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_Load_Dim_Customer
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @LoadDate DATETIME = GETDATE();

    -- Expire current rows whose tracked attributes changed
    UPDATE tgt
    SET tgt.eff_end_dt   = @LoadDate,
        tgt.is_curr_flag = 0
    FROM dbo.dim_customer tgt
    INNER JOIN dbo.stg_customer src
        ON tgt.cust_id = src.cust_id
    WHERE tgt.is_curr_flag = 1
      AND (   ISNULL(tgt.cust_nm, '')   <> ISNULL(src.cust_nm, '')
           OR ISNULL(tgt.cust_addr, '') <> ISNULL(src.cust_addr, '')
           OR ISNULL(tgt.cust_city, '') <> ISNULL(src.cust_city, '')
           OR ISNULL(tgt.cust_seg, '')  <> ISNULL(src.cust_seg, '') );

    -- Insert new versions + brand-new customers
    INSERT INTO dbo.dim_customer
        (cust_id, cust_nm, cust_addr, cust_city, cust_seg,
         eff_start_dt, eff_end_dt, is_curr_flag)
    SELECT src.cust_id, src.cust_nm, src.cust_addr, src.cust_city,
           src.cust_seg, @LoadDate, '9999-12-31', 1
    FROM dbo.stg_customer src
    LEFT JOIN dbo.dim_customer tgt
        ON src.cust_id = tgt.cust_id AND tgt.is_curr_flag = 1
    WHERE tgt.cust_id IS NULL;
END
GO
