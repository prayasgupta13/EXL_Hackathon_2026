/* =====================================================================
   Procedure 5 of 5  —  Retention purge
   Complexity : N/A
   Drift      : N/A
   Expected   : UNSUPPORTED — dynamic SQL. The target table is a runtime
                parameter, so no static conversion is possible. Must be
                routed to human review rather than silently mistranslated.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_Purge_Old_Partitions
    @TableName SYSNAME,
    @RetentionDays INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @sql NVARCHAR(MAX);

    SET @sql = N'DELETE FROM dbo.' + QUOTENAME(@TableName) +
               N' WHERE load_dt < DATEADD(DAY, -' +
               CAST(@RetentionDays AS NVARCHAR(10)) + N', GETDATE());';

    EXEC sp_executesql @sql;

    INSERT INTO dbo.etl_audit_log (table_nm, action_typ, action_dt)
    VALUES (@TableName, 'PURGE', GETDATE());
END
GO
