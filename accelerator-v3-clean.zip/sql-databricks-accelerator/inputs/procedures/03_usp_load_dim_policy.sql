/* =====================================================================
   Procedure 3 of 5  —  SCD Type 2 policy dimension load
   Complexity : MEDIUM
   Drift      : TYPE MISMATCH — treats stg_policy.prem_amt as a decimal,
                but the raw layer landed it as STRING.
                Expected: flagged as a data-type drift for human review.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_Load_Dim_Policy
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @LoadDate DATETIME = GETDATE();

    UPDATE tgt
    SET tgt.eff_end_dt   = @LoadDate,
        tgt.is_curr_flag = 0
    FROM dbo.dim_policy tgt
    INNER JOIN dbo.stg_policy src
        ON tgt.pol_no = src.pol_no
    WHERE tgt.is_curr_flag = 1
      AND (   ISNULL(tgt.pol_typ, '')       <> ISNULL(src.pol_typ, '')
           OR ISNULL(tgt.prem_amt, 0)       <> ISNULL(src.prem_amt, 0)
           OR ISNULL(tgt.pol_sts, '')       <> ISNULL(src.pol_sts, '') );

    INSERT INTO dbo.dim_policy
        (pol_no, cust_id, pol_typ, prem_amt, pol_start_dt, pol_sts,
         eff_start_dt, eff_end_dt, is_curr_flag)
    SELECT src.pol_no, src.cust_id, src.pol_typ, src.prem_amt,
           src.pol_start_dt, src.pol_sts, @LoadDate, '9999-12-31', 1
    FROM dbo.stg_policy src
    LEFT JOIN dbo.dim_policy tgt
        ON src.pol_no = tgt.pol_no AND tgt.is_curr_flag = 1
    WHERE tgt.pol_no IS NULL;
END
GO
