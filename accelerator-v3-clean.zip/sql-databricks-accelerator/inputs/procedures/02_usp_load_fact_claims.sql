/* =====================================================================
   Procedure 2 of 5  —  Claims fact load
   Complexity : HIGH  (temp table, multi-table joins, CASE, DATEDIFF)
   Drift      : MISSING COLUMN — references stg_claims.deductible_amt,
                which does NOT exist in the Databricks raw layer.
                Expected: flagged as schema drift for human review.
   ===================================================================== */
CREATE OR ALTER PROCEDURE dbo.usp_Load_Fact_Claims
    @BatchDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        c.claim_no,
        c.pol_no,
        c.cust_id,
        c.claim_dt,
        c.claim_amt,
        c.deductible_amt,                    -- DRIFT: not present in raw
        c.claim_sts,
        CASE WHEN c.claim_amt > 100000 THEN 'HIGH'
             WHEN c.claim_amt > 25000  THEN 'MEDIUM'
             ELSE 'LOW' END              AS claim_severity,
        DATEDIFF(DAY, c.claim_dt, c.settled_dt) AS days_to_settle
    INTO #eligible_claims
    FROM dbo.stg_claims c
    WHERE c.claim_sts IN ('SETTLED', 'APPROVED')
      AND c.claim_dt <= @BatchDate;

    INSERT INTO dbo.fact_claims
        (claim_no, pol_no, cust_sk, claim_dt, claim_amt, net_claim_amt,
         claim_severity, days_to_settle, load_dt)
    SELECT
        ec.claim_no, ec.pol_no, dc.cust_sk, ec.claim_dt, ec.claim_amt,
        ec.claim_amt - ISNULL(ec.deductible_amt, 0) AS net_claim_amt,
        ec.claim_severity, ISNULL(ec.days_to_settle, -1), GETDATE()
    FROM #eligible_claims ec
    INNER JOIN dbo.dim_customer dc
        ON ec.cust_id = dc.cust_id AND dc.is_curr_flag = 1
    LEFT JOIN dbo.fact_claims f
        ON ec.claim_no = f.claim_no
    WHERE f.claim_no IS NULL;

    DROP TABLE #eligible_claims;
END
GO
