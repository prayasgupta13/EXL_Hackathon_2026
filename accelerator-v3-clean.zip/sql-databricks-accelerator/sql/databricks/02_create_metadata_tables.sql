-- =====================================================================
-- ONE-TIME TARGET SETUP (2 of 2) — Metadata schema
-- Run after 01_create_medallion.sql.
--
-- These four tables are the accelerator's control plane. All are APPEND
-- tables: every run adds rows, nothing is overwritten, so the migration
-- has a complete audit trail.
--
--   schema_registry  <- written by PHASE 1 (parse procedures)
--   schema_drift     <- written by PHASE 2 (compare registry vs raw)
--   lineage          <- written by PHASE 3 (raw -> std -> dwh paths)
--   execution_log    <- written by every phase
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS hackathon.metadata;

-- ---------------------------------------------------------------------
-- 1. SCHEMA REGISTRY  (generated from the stored procedures)
--    One row per source column per target layer. Appended per procedure,
--    so converting a new procedure extends the registry rather than
--    replacing it.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hackathon.metadata.schema_registry (
    registry_id      STRING,      -- deterministic hash: dedupe across reruns
    source_system    STRING,      -- SQLSERVER_PROD01 (extensible: ORACLE, TERADATA)
    source_dialect   STRING,      -- tsql / plsql / teradata
    procedure_name   STRING,      -- which procedure contributed this row
    source_schema    STRING,
    source_table     STRING,
    source_column    STRING,
    source_type      STRING,      -- as inferred from the procedure
    target_layer     STRING,      -- raw / std / dwh
    target_schema    STRING,
    target_table     STRING,
    target_column    STRING,
    target_type      STRING,
    transform_rule   STRING,      -- TRIM / UPPER / CAST / LOOKUP:... 
    is_derived       BOOLEAN,     -- true = computed in the proc, not a source column
    derivation_logic STRING,      -- e.g. CASE expression for claim_severity
    generated_on     TIMESTAMP,
    generated_by     STRING       -- 'registry_builder'
) USING DELTA;

-- ---------------------------------------------------------------------
-- 2. SCHEMA DRIFT  (registry vs ACTUAL raw layer schema)
--    Written whenever the procedures expect something the raw layer does
--    not provide. This is detection, not narrative — rows appear only
--    because a real comparison found a real gap.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hackathon.metadata.schema_drift (
    drift_id         STRING,      -- deterministic hash of the finding
    detected_on      TIMESTAMP,
    procedure_name   STRING,
    source_table     STRING,      -- as referenced by the procedure
    raw_table        STRING,      -- expected fully-qualified raw table
    column_name      STRING,      -- null for missing-table findings
    drift_type       STRING,      -- MISSING_TABLE / MISSING_COLUMN /
                                  -- TYPE_MISMATCH / EXTRA_COLUMN
    expected_value   STRING,      -- what the procedure implies
    actual_value     STRING,      -- what raw actually has (null if absent)
    severity         STRING,      -- BLOCKER / WARNING
    resolution_mode  STRING,      -- AUTO / APPROVAL_REQUIRED
    review_status    STRING,      -- OPEN / ACCEPTED / REJECTED / RESOLVED
    reviewed_by      STRING,
    reviewed_on      TIMESTAMP,
    reviewer_notes   STRING
) USING DELTA;

-- ---------------------------------------------------------------------
-- 3. LINEAGE  (column path raw -> std -> dwh)
--    Generated once the registry is clean. The code generator resolves
--    every column name through this table, so generated code cannot drift
--    from the agreed mapping.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hackathon.metadata.lineage (
    lineage_id       STRING,
    procedure_name   STRING,
    raw_table        STRING,
    raw_column       STRING,
    raw_type         STRING,
    std_table        STRING,
    std_column       STRING,
    std_type         STRING,
    std_transform    STRING,      -- rename/cast applied raw -> std
    dwh_table        STRING,
    dwh_column       STRING,
    dwh_type         STRING,
    dwh_transform    STRING,      -- business logic applied std -> dwh
    is_business_key  BOOLEAN,
    is_scd2_tracked  BOOLEAN,     -- change in this column creates a new version
    generated_on     TIMESTAMP
) USING DELTA;

-- ---------------------------------------------------------------------
-- 4. EXECUTION LOG  (every phase, every run)
--    Created here so the very first accelerator run has somewhere to
--    write; the code also creates it if absent.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS hackathon.metadata.execution_log (
    run_id           STRING,      -- one id per accelerator invocation
    phase            STRING,      -- REGISTRY / DRIFT / LINEAGE / CODEGEN / VALIDATE
    procedure_name   STRING,
    status           STRING,      -- SUCCESS / FAILED / SKIPPED / HUMAN_REVIEW
    rows_affected    BIGINT,
    message          STRING,
    started_at       TIMESTAMP,
    ended_at         TIMESTAMP,
    duration_seconds DOUBLE,
    executed_by      STRING
) USING DELTA;

-- ---------------------------------------------------------------------
-- Handy review queries (use these in the demo)
-- ---------------------------------------------------------------------

-- Open drift items awaiting human review:
-- SELECT procedure_name, source_table, column_name, drift_type,
--        expected_value, actual_value, severity
-- FROM hackathon.metadata.schema_drift
-- WHERE review_status = 'OPEN' ORDER BY severity, detected_on;

-- Full column lineage for one table:
-- SELECT raw_column, std_column, dwh_column, std_transform, dwh_transform
-- FROM hackathon.metadata.lineage
-- WHERE raw_table = 'hackathon.raw.stg_customer' ORDER BY raw_column;

-- Last run summary:
-- SELECT phase, status, count(*) AS n, sum(rows_affected) AS rows
-- FROM hackathon.metadata.execution_log
-- WHERE run_id = (SELECT max(run_id) FROM hackathon.metadata.execution_log)
-- GROUP BY phase, status;

SHOW TABLES IN hackathon.metadata;
