-- =====================================================================
-- ONE-TIME TARGET SETUP (1 of 2) — Medallion architecture
-- Run this first in a Databricks SQL editor.
--
-- Creates: hackathon.raw / .std / .dwh  (+ seed data in raw)
--
-- IMPORTANT — the raw layer is deliberately INCOMPLETE relative to the
-- stored procedures. These gaps are what the drift detector must find:
--
--   * stg_claims  is MISSING the column `deductible_amt`   (proc 02)
--   * stg_policy  lands `prem_amt` as STRING, not DECIMAL  (proc 03)
--   * stg_premium_txn does NOT EXIST at all                (proc 04)
--
-- Do not "fix" these before running the accelerator — they are the demo.
-- =====================================================================

CREATE CATALOG IF NOT EXISTS hackathon;

CREATE SCHEMA IF NOT EXISTS hackathon.raw;
CREATE SCHEMA IF NOT EXISTS hackathon.std;
CREATE SCHEMA IF NOT EXISTS hackathon.dwh;

-- ---------------------------------------------------------------------
-- RAW LAYER — mirrors the SQL Server source (same column names)
-- ---------------------------------------------------------------------

-- stg_customer: complete, matches proc 01 exactly (no drift)
CREATE OR REPLACE TABLE hackathon.raw.stg_customer (
    cust_id      INT,
    cust_nm      STRING,
    cust_addr    STRING,
    cust_city    STRING,
    cust_seg     STRING,
    _ingest_ts   TIMESTAMP,
    _source_file STRING
) USING DELTA;

INSERT INTO hackathon.raw.stg_customer VALUES
(101,'Arjun Mehta','12 MG Road','Bengaluru','RETAIL',   current_timestamp(),'stg_customer_20260724.csv'),
(102,'Priya Sharma','45 Sector 18','Noida','PREMIUM',   current_timestamp(),'stg_customer_20260724.csv'),
(103,'Rahul Verma','8 Park Street','Kolkata','RETAIL',  current_timestamp(),'stg_customer_20260724.csv'),
(104,'Sneha Iyer','23 Anna Salai','Chennai','CORPORATE',current_timestamp(),'stg_customer_20260724.csv');

-- stg_claims: MISSING deductible_amt -> proc 02 triggers column drift
CREATE OR REPLACE TABLE hackathon.raw.stg_claims (
    claim_no     STRING,
    pol_no       STRING,
    cust_id      INT,
    claim_dt     DATE,
    claim_amt    DECIMAL(18,2),
    claim_sts    STRING,
    settled_dt   DATE,
    _ingest_ts   TIMESTAMP,
    _source_file STRING
) USING DELTA;

INSERT INTO hackathon.raw.stg_claims VALUES
('CLM-9001','POL-5001',101,DATE'2026-05-10', 15000.00,'SETTLED', DATE'2026-05-28',current_timestamp(),'stg_claims_20260724.csv'),
('CLM-9002','POL-5002',102,DATE'2026-05-15',145000.00,'SETTLED', DATE'2026-06-30',current_timestamp(),'stg_claims_20260724.csv'),
('CLM-9003','POL-5003',103,DATE'2026-06-01', 42000.00,'APPROVED',NULL,           current_timestamp(),'stg_claims_20260724.csv'),
('CLM-9004','POL-5001',101,DATE'2026-06-20',  8000.00,'REJECTED',NULL,           current_timestamp(),'stg_claims_20260724.csv');

-- stg_policy: prem_amt landed as STRING -> proc 03 triggers type drift
CREATE OR REPLACE TABLE hackathon.raw.stg_policy (
    pol_no       STRING,
    cust_id      INT,
    pol_typ      STRING,
    prem_amt     STRING,          -- DRIFT: should be DECIMAL(18,2)
    pol_start_dt DATE,
    pol_sts      STRING,
    _ingest_ts   TIMESTAMP,
    _source_file STRING
) USING DELTA;

INSERT INTO hackathon.raw.stg_policy VALUES
('POL-5001',101,'MOTOR',     '12500.00',DATE'2025-04-01','ACTIVE', current_timestamp(),'stg_policy_20260724.csv'),
('POL-5002',102,'HEALTH',    '48000.50',DATE'2025-07-15','ACTIVE', current_timestamp(),'stg_policy_20260724.csv'),
('POL-5003',103,'MOTOR',      '9800.00',DATE'2026-01-10','ACTIVE', current_timestamp(),'stg_policy_20260724.csv'),
('POL-5004',104,'PROPERTY','156000.00',DATE'2024-11-20','LAPSED', current_timestamp(),'stg_policy_20260724.csv');

-- NOTE: hackathon.raw.stg_premium_txn is INTENTIONALLY NOT CREATED.
-- Proc 04 reads it -> the detector must report a missing-table drift.

-- ---------------------------------------------------------------------
-- STD LAYER — cleaned / standardised names. Populated by the pipeline.
-- ---------------------------------------------------------------------
CREATE OR REPLACE TABLE hackathon.std.customer (
    customer_id      INT,
    customer_name    STRING,
    customer_address STRING,
    customer_city    STRING,
    customer_segment STRING,
    _std_load_ts     TIMESTAMP
) USING DELTA;

CREATE OR REPLACE TABLE hackathon.std.claims (
    claim_number  STRING,
    policy_number STRING,
    customer_id   INT,
    claim_date    DATE,
    claim_amount  DECIMAL(18,2),
    claim_status  STRING,
    settled_date  DATE,
    _std_load_ts  TIMESTAMP
) USING DELTA;

CREATE OR REPLACE TABLE hackathon.std.policy (
    policy_number     STRING,
    customer_id       INT,
    policy_type       STRING,
    premium_amount    DECIMAL(18,2),
    policy_start_date DATE,
    policy_status     STRING,
    _std_load_ts      TIMESTAMP
) USING DELTA;

-- ---------------------------------------------------------------------
-- DWH LAYER — modelled warehouse. SCD2 dimensions + facts.
-- ---------------------------------------------------------------------
CREATE OR REPLACE TABLE hackathon.dwh.dim_customer (
    customer_sk          BIGINT GENERATED ALWAYS AS IDENTITY,
    customer_id          INT,
    customer_name        STRING,
    customer_address     STRING,
    customer_city        STRING,
    customer_segment     STRING,
    effective_start_date TIMESTAMP,
    effective_end_date   TIMESTAMP,
    is_current           BOOLEAN
) USING DELTA
TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- Seed an OLD version of customer 102 so the generated SCD2 code has a
-- change to detect: raw says Noida/PREMIUM, dwh currently says Delhi/RETAIL.
INSERT INTO hackathon.dwh.dim_customer
    (customer_id, customer_name, customer_address, customer_city,
     customer_segment, effective_start_date, effective_end_date, is_current)
VALUES
(101,'Arjun Mehta','12 MG Road','Bengaluru','RETAIL',
     TIMESTAMP'2026-01-01 00:00:00', TIMESTAMP'9999-12-31 00:00:00', true),
(102,'Priya Sharma','7 Old Colony Rd','Delhi','RETAIL',
     TIMESTAMP'2026-01-01 00:00:00', TIMESTAMP'9999-12-31 00:00:00', true);

CREATE OR REPLACE TABLE hackathon.dwh.dim_policy (
    policy_sk            BIGINT GENERATED ALWAYS AS IDENTITY,
    policy_number        STRING,
    customer_id          INT,
    policy_type          STRING,
    premium_amount       DECIMAL(18,2),
    policy_start_date    DATE,
    policy_status        STRING,
    effective_start_date TIMESTAMP,
    effective_end_date   TIMESTAMP,
    is_current           BOOLEAN
) USING DELTA
TBLPROPERTIES (delta.enableChangeDataFeed = true);

CREATE OR REPLACE TABLE hackathon.dwh.fact_claims (
    claim_number   STRING,
    policy_number  STRING,
    customer_sk    BIGINT,
    claim_date     DATE,
    claim_amount   DECIMAL(18,2),
    net_claim_amount DECIMAL(18,2),
    claim_severity STRING,
    days_to_settle INT,
    load_date      TIMESTAMP
) USING DELTA;

CREATE OR REPLACE TABLE hackathon.dwh.fact_premium (
    policy_number    STRING,
    customer_sk      BIGINT,
    txn_month        STRING,
    total_premium_amount DECIMAL(18,2),
    txn_count        BIGINT,
    load_date        TIMESTAMP
) USING DELTA;

-- ---------------------------------------------------------------------
-- Confirm what was created
-- ---------------------------------------------------------------------
SHOW TABLES IN hackathon.raw;
SHOW TABLES IN hackathon.std;
SHOW TABLES IN hackathon.dwh;
