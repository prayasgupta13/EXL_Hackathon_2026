/* =====================================================================
   ONE-TIME SOURCE SETUP  (SQL Server)
   Reference DDL for the staging + target objects the five procedures use.
   Run on a SQL Server instance if you want a live source; otherwise this
   documents the schema the accelerator parses the procedures against.
   ===================================================================== */

-- ---------------------------------------------------------------------
-- STAGING TABLES (extracted to the Databricks raw layer)
-- ---------------------------------------------------------------------
CREATE TABLE dbo.stg_customer (
    cust_id   INT           NOT NULL,
    cust_nm   NVARCHAR(200),
    cust_addr NVARCHAR(500),
    cust_city NVARCHAR(100),
    cust_seg  NVARCHAR(50)
);

CREATE TABLE dbo.stg_claims (
    claim_no       NVARCHAR(20) NOT NULL,
    pol_no         NVARCHAR(20),
    cust_id        INT,
    claim_dt       DATE,
    claim_amt      DECIMAL(18,2),
    deductible_amt DECIMAL(18,2),   -- present at source; NOT landed in raw
    claim_sts      NVARCHAR(20),
    settled_dt     DATE
);

CREATE TABLE dbo.stg_policy (
    pol_no       NVARCHAR(20) NOT NULL,
    cust_id      INT,
    pol_typ      NVARCHAR(50),
    prem_amt     DECIMAL(18,2),     -- decimal at source; landed as STRING in raw
    pol_start_dt DATE,
    pol_sts      NVARCHAR(20)
);

CREATE TABLE dbo.stg_premium_txn (   -- never landed in raw at all
    txn_id  BIGINT NOT NULL,
    pol_no  NVARCHAR(20),
    cust_id INT,
    txn_dt  DATE,
    txn_amt DECIMAL(18,2),
    txn_sts NVARCHAR(20)
);

-- ---------------------------------------------------------------------
-- TARGET TABLES (what the procedures load, pre-migration)
-- ---------------------------------------------------------------------
CREATE TABLE dbo.dim_customer (
    cust_sk      BIGINT IDENTITY(1,1),
    cust_id      INT,
    cust_nm      NVARCHAR(200),
    cust_addr    NVARCHAR(500),
    cust_city    NVARCHAR(100),
    cust_seg     NVARCHAR(50),
    eff_start_dt DATETIME,
    eff_end_dt   DATETIME,
    is_curr_flag BIT
);

CREATE TABLE dbo.dim_policy (
    pol_sk       BIGINT IDENTITY(1,1),
    pol_no       NVARCHAR(20),
    cust_id      INT,
    pol_typ      NVARCHAR(50),
    prem_amt     DECIMAL(18,2),
    pol_start_dt DATE,
    pol_sts      NVARCHAR(20),
    eff_start_dt DATETIME,
    eff_end_dt   DATETIME,
    is_curr_flag BIT
);

CREATE TABLE dbo.fact_claims (
    claim_no       NVARCHAR(20),
    pol_no         NVARCHAR(20),
    cust_sk        BIGINT,
    claim_dt       DATE,
    claim_amt      DECIMAL(18,2),
    net_claim_amt  DECIMAL(18,2),
    claim_severity NVARCHAR(10),
    days_to_settle INT,
    load_dt        DATETIME
);

CREATE TABLE dbo.fact_premium (
    pol_no         NVARCHAR(20),
    cust_sk        BIGINT,
    txn_month      CHAR(7),
    total_prem_amt DECIMAL(18,2),
    txn_cnt        INT,
    load_dt        DATETIME
);

CREATE TABLE dbo.etl_audit_log (
    table_nm    SYSNAME,
    action_typ  NVARCHAR(20),
    action_dt   DATETIME
);
